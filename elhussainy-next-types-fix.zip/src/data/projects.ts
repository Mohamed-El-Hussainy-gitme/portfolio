// src/data/projects.ts

export type Locale = "en" | "ar";

export interface LocalizedText {
  en: string;
  ar: string;
}

export interface ProjectScreen {
  id: string;
  src: string;
  alt: string;
}

export interface ProjectHighlight {
  id: "keyPoints" | "focus" | "role" | "deployment";
  label: LocalizedText;
  body: LocalizedText;
}

export interface ProjectFaq {
  q: LocalizedText;
  a: LocalizedText;
}

export interface ProjectCaseStudy {
  problem: LocalizedText;
  solution: LocalizedText;
  outcome: LocalizedText;
  role: LocalizedText;
  stack: LocalizedText;
  steps: { en: string[]; ar: string[] };
  faqs: ProjectFaq[];
}

export interface ProjectDefinition {
  id: string;
  universe: number;
  slug: string;
  name: LocalizedText;
  tagline: LocalizedText;
  description: LocalizedText;

  /** SEO: simple short focus keyword (used across title/description/content). */
  focusKeyword?: LocalizedText;
  /** SEO: per-project title (recommended <= 60 chars; clamped at runtime). */
  seoTitle?: LocalizedText;
  /** SEO: per-project description (recommended <= 160 chars; clamped at runtime). */
  seoDescription?: LocalizedText;

  techStack: string[];
  tags: string[];
  repoUrl?: string;
  liveUrl?: string;

  screens: ProjectScreen[];
  highlights: ProjectHighlight[];

  /** Case Study content unique per project */
  caseStudy?: ProjectCaseStudy;
}

export const projects: ProjectDefinition[] = [
  /**
   * 01 – Mini Shop – Single Page Store
   */
  {
    id: "mini-shop",
    universe: 1,
    slug: "project-1",
    focusKeyword: {
      en: "single page store",
      ar: "متجر صفحة واحدة",
    },
    seoTitle: {
      en: "Single Page Store: Mini Shop Case Study",
      ar: "متجر صفحة واحدة: دراسة حالة Mini Shop",
    },
    seoDescription: {
      en: "Single page store with cart and checkout in Arabic. Clean UX, responsive layout, and simple e-commerce flow.",
      ar: "متجر صفحة واحدة مع سلة ودفع بالعربية. تجربة واضحة، تصميم متجاوب، وتدفق شراء بسيط.",
    },
    name: {
      en: "Mini Shop – Single Page Store",
      ar: "Mini Shop – متجر صفحة واحدة",
    },
    tagline: {
      en: "Single-page Arabic storefront with cart and checkout, built in pure HTML, CSS, and JavaScript.",
      ar: "متجر صفحة واحدة باللغة العربية مع سلة شراء وخطوة دفع، مبني بالكامل باستخدام HTML وCSS وJavaScript.",
    },
    description: {
      en: [
        "Mini Shop – Single Page Store is a lightweight demo shop built with HTML, CSS, and vanilla JavaScript.",
        "The page combines a simple hero, product grid, cart, and checkout section into one scrolling experience to showcase basic front-end e-commerce UX in Arabic.",
      ].join(" "),
      ar: [
        "Mini Shop – Single Page Store هو مشروع متجر إلكتروني خفيف مبني باستخدام HTML وCSS وJavaScript بدون أي إطار عمل.",
        "تجمع الصفحة بين قسم تعريفي بسيط وشبكة منتجات وسلة شراء وقسم دفع في تجربة تمرير واحدة تعرض أساسيات واجهات المتاجر العربية على الويب.",
      ].join(" "),
    },
    techStack: ["HTML", "CSS", "JavaScript"],
    tags: ["ecommerce", "frontend", "ui"],
    repoUrl: "https://github.com/Mohamed-El-Hussainy-gitme/single-page-website",
    liveUrl: "https://mohamed-el-hussainy-gitme.github.io/single-page-website/",
    screens: [
      { id: "mini-shop-1", src: "/assets/project1/Screenshot 2025-11-27 151701.png", alt: "Single page store Arabic UI — Mini Shop hero and product grid" },
      { id: "mini-shop-2", src: "/assets/project1/Screenshot 2025-11-27 152128.png", alt: "Single page store — product cards and add to cart" },
      { id: "mini-shop-3", src: "/assets/project1/Screenshot 2025-11-27 153625.png", alt: "Single page store — cart section UI" },
      { id: "mini-shop-4", src: "/assets/project1/Screenshot 2025-11-27 153722.png", alt: "Single page store — cart items and totals" },
      { id: "mini-shop-5", src: "/assets/project1/Screenshot 2025-11-27 153802.png", alt: "Single page store — checkout form layout" },
      { id: "mini-shop-6", src: "/assets/project1/Screenshot 2025-11-27 154052.png", alt: "Single page store — checkout confirmation flow" },
      { id: "mini-shop-7", src: "/assets/project1/Screenshot 2025-11-27 154118.png", alt: "Single page store — responsive layout section" },
      { id: "mini-shop-8", src: "/assets/project1/Screenshot 2025-11-27 154445.png", alt: "Single page store — footer and navigation" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "Fake products, add-to-cart flow, cart and checkout section, and a clean one-page responsive layout with navbar and footer.",
          ar: "منتجات تجريبية، إضافة للسلة مع عرض سلة الشراء وقسم الدفع، وتخطيط صفحة واحدة متجاوب مع شريط تنقّل وتذييل بسيطين.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "Showcasing a compact Arabic shopping flow with product listing, cart, and checkout in a single scrollable page.",
          ar: "عرض تجربة تسوّق عربية مضغوطة تجمع عرض المنتجات والسلة والدفع في صفحة واحدة قابلة للتمرير.",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "Front-end design and implementation using pure HTML, CSS, and JavaScript.",
          ar: "تصميم الواجهة وتنفيذها بالكامل باستخدام HTML وCSS وJavaScript فقط.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "Users needed a quick single-page store experience in Arabic where product browsing, cart, and checkout feel immediate without multi-page complexity.",
        ar: "كان الهدف تقديم متجر صفحة واحدة بالعربية يختصر رحلة الشراء: تصفح المنتجات ثم السلة ثم الدفع بدون تعقيد صفحات كثيرة.",
      },
      solution: {
        en: "Built a single scrolling layout that keeps product grid, cart, and checkout in one flow, with clear CTA and predictable UI states.",
        ar: "تم بناء تخطيط تمرير واحد يدمج شبكة المنتجات والسلة والدفع في مسار واضح مع أزرار وإشعارات حالة بسيطة وسهلة الفهم.",
      },
      outcome: {
        en: "A clean demo for single-page store UX that proves layout, cart interactions, and checkout clarity on desktop and mobile.",
        ar: "نتيجة المشروع نموذج عملي لمتجر صفحة واحدة يثبت وضوح الواجهة وتفاعل السلة وسهولة الوصول لخطوة الدفع على الموبايل والديسكتوب.",
      },
      role: {
        en: "UI build + vanilla JS cart logic + responsive layout.",
        ar: "تنفيذ الواجهة + منطق السلة بـ JavaScript + تصميم متجاوب.",
      },
      stack: {
        en: "HTML • CSS • JavaScript",
        ar: "HTML • CSS • JavaScript",
      },
      steps: {
        en: [
          "Define the single-page shopping flow",
          "Design product cards and cart UI states",
          "Implement add-to-cart and quantity updates",
          "Build checkout section and validation hints",
          "Test responsiveness and basic accessibility",
        ],
        ar: [
          "تحديد مسار الشراء في صفحة واحدة",
          "تصميم بطاقات المنتجات وحالات السلة",
          "تنفيذ الإضافة للسلة وتعديل الكميات",
          "إنشاء قسم الدفع وتلميحات التحقق",
          "اختبار التوافق مع الموبايل وإمكانية الوصول",
        ],
      },
      faqs: [
        {
          q: { en: "Is this a full e-commerce backend?", ar: "هل هذا متجر كامل بباك إند؟" },
          a: { en: "No. It is a front-end single page store demo focused on UX and cart/checkout behavior.", ar: "لا. هو نموذج واجهة يركز على تجربة المستخدم وتفاعل السلة والدفع." },
        },
        {
          q: { en: "Can it be converted to a real store?", ar: "هل يمكن تحويله لمتجر حقيقي؟" },
          a: { en: "Yes. The UI flow can be reused and connected to APIs, payments, and an admin dashboard.", ar: "نعم. يمكن إعادة استخدام نفس التدفق وربطه بـ API وبوابات الدفع ولوحة تحكم." },
        },
        {
          q: { en: "Does it support Arabic RTL?", ar: "هل يدعم العربية وRTL؟" },
          a: { en: "Yes. The layout is built with Arabic-first direction and spacing.", ar: "نعم. التخطيط مبني ليكون مناسبًا للعربية واتجاه RTL." },
        },
      ],
    },
  },

  /**
   * 02 – Real Estate UI
   */
  {
    id: "real-estate-ui",
    universe: 2,
    slug: "project-2",
    focusKeyword: { en: "real estate UI", ar: "واجهة عقارات" },
    seoTitle: { en: "Real Estate UI: Arabic RTL Case Study", ar: "واجهة عقارات: دراسة حالة RTL" },
    seoDescription: {
      en: "Real estate UI with advanced filters, property pages, and map. Arabic RTL, dark mode, and responsive UX.",
      ar: "واجهة عقارات بفلاتر متقدمة وصفحات تفاصيل وخريطة. دعم RTL، وضع داكن، وتجربة متجاوبة.",
    },
    name: { en: "Real Estate UI", ar: "Real Estate UI" },
    tagline: {
      en: "Arabic RTL real estate interface with advanced filters, dark mode, map, and detailed property pages.",
      ar: "واجهة عقارات عربية باتجاه RTL مع فلاتر متقدمة، وضع داكن، خريطة تفاعلية وصفحات تفاصيل كاملة للعقار.",
    },
    description: {
      en: [
        "Real Estate UI is a modern React + Vite front-end for browsing properties.",
        "It includes a full Arabic RTL layout, advanced filtering by price, area, rooms, property type, and city, text search in titles and locations, a dedicated property details page with image carousel and interactive map built with React Leaflet, plus a dark-mode theme and fully responsive layout.",
      ].join(" "),
      ar: [
        "Real Estate UI هو واجهة حديثة مبنية بـ React وVite لاستعراض العقارات.",
        "يوفّر تخطيطًا عربيًا كاملًا (RTL)، وفلاتر متقدمة حسب السعر والمساحة وعدد الغرف ونوع العقار والمدينة مع بحث نصي في العناوين والمواقع، وصفحة مخصّصة لتفاصيل العقار تضم معرض صور وخريطة تفاعلية مبنية بـ React Leaflet، بالإضافة إلى وضع داكن وتخطيط متجاوب بالكامل.",
      ].join(" "),
    },
    techStack: ["React", "Vite", "Tailwind CSS", "React Router", "React Leaflet", "Swiper"],
    tags: ["real-estate", "map", "frontend", "ui", "rtl"],
    repoUrl: "https://github.com/Mohamed-El-Hussainy-gitme/real-estate-ui",
    liveUrl: "https://mohamed-el-hussainy-gitme.github.io/real-estate-ui/",
    screens: [
      { id: "real-estate-1", src: "/assets/project2/Screenshot 2025-12-01 003246.png", alt: "Real estate UI — hero and filters panel (Arabic RTL)" },
      { id: "real-estate-2", src: "/assets/project2/Screenshot 2025-12-01 003410.png", alt: "Real estate UI — filtered properties grid" },
      { id: "real-estate-3", src: "/assets/project2/Screenshot 2025-12-01 003526.png", alt: "Real estate UI — property details page" },
      { id: "real-estate-4", src: "/assets/project2/Screenshot 2025-12-01 003635.png", alt: "Real estate UI — property details layout and gallery" },
      { id: "real-estate-5", src: "/assets/project2/Screenshot 2025-12-01 003653.png", alt: "Real estate UI — property map section (React Leaflet)" },
      { id: "real-estate-6", src: "/assets/project2/Screenshot 2025-12-01 003738.png", alt: "Real estate UI — dark mode view" },
      { id: "real-estate-7", src: "/assets/project2/Screenshot 2025-12-01 003810.png", alt: "Real estate UI — ordering / request section" },
      { id: "real-estate-8", src: "/assets/project2/Screenshot 2025-12-01 003825.png", alt: "Real estate UI — dark mode details" },
      { id: "real-estate-9", src: "/assets/project2/Screenshot 2025-12-01 003846.png", alt: "Real estate UI — dark mode details with map" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "Hero landing, advanced filters, Arabic RTL layout, property cards grid, details page with gallery, interactive map, and dark mode toggle.",
          ar: "واجهة رئيسية مع قسم Hero، فلاتر متقدمة، تخطيط عربي RTL كامل، شبكة بطاقات للعقارات، صفحة تفاصيل مع معرض صور، خريطة تفاعلية، وزر للتبديل إلى الوضع الداكن.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "Make searching and comparing properties fast through filters, search, and map navigation.",
          ar: "جعل البحث عن العقارات ومقارنتها أسرع عبر الفلاتر والبحث النصي والتصفح من خلال الخريطة التفاعلية.",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "Front-end architecture, UI/UX design, RTL layout, and dark-mode implementation.",
          ar: "هندسة الواجهة الأمامية، تصميم واجهة وتجربة المستخدم، ضبط RTL، وتنفيذ نمط الوضع الداكن.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "Property browsing becomes slow when filters and map context are separate. Users needed faster comparison with RTL-first Arabic UI.",
        ar: "تصفح العقارات يصبح بطيئًا عندما تكون الفلاتر والخريطة منفصلين. كان المطلوب مقارنة أسرع بواجهة عربية RTL صحيحة.",
      },
      solution: {
        en: "Built an RTL-first search experience: advanced filters + text search + dedicated details page with gallery and live map context.",
        ar: "تم بناء تجربة بحث RTL: فلاتر متقدمة + بحث نصي + صفحة تفاصيل بمعرض صور وخريطة تفاعلية تعطي سياقًا فوريًا للموقع.",
      },
      outcome: {
        en: "A real estate UI that makes discovery and comparison faster, with clear details and map-based trust signals.",
        ar: "واجهة عقارات تسهّل الاكتشاف والمقارنة بسرعة، مع تفاصيل واضحة وخريطة تدعم قرار المستخدم.",
      },
      role: {
        en: "UI architecture, RTL, filters state, and map integration.",
        ar: "هندسة الواجهة، RTL، إدارة حالة الفلاتر، ودمج الخريطة.",
      },
      stack: {
        en: "React • Tailwind • React Router • Leaflet",
        ar: "React • Tailwind • React Router • Leaflet",
      },
      steps: {
        en: [
          "Define filter taxonomy (price/area/rooms/type/city)",
          "Design RTL layout and responsive cards",
          "Build filter state + search behavior",
          "Implement details page + gallery",
          "Integrate map and coordinates display",
          "Add dark mode and polish interactions",
        ],
        ar: [
          "تحديد تصنيف الفلاتر (سعر/مساحة/غرف/نوع/مدينة)",
          "تصميم تخطيط RTL وبطاقات متجاوبة",
          "تنفيذ حالة الفلاتر والبحث النصي",
          "إنشاء صفحة التفاصيل ومعرض الصور",
          "دمج الخريطة وإظهار الإحداثيات",
          "إضافة الوضع الداكن وتحسين التفاعلات",
        ],
      },
      faqs: [
        {
          q: { en: "Is the map interactive?", ar: "هل الخريطة تفاعلية؟" },
          a: { en: "Yes. It uses React Leaflet with real markers and location context.", ar: "نعم. تم استخدام React Leaflet مع مؤشرات ومعلومات موقع." },
        },
        {
          q: { en: "Does it support Arabic RTL properly?", ar: "هل يدعم RTL للعربية بشكل صحيح؟" },
          a: { en: "Yes. Layout direction, spacing, and UI alignment are RTL-first.", ar: "نعم. الاتجاه والمسافات ومحاذاة العناصر تم ضبطها للعربية." },
        },
        {
          q: { en: "Can this UI connect to a backend?", ar: "هل يمكن ربط الواجهة بباك إند؟" },
          a: { en: "Yes. Filters and routes are ready to be connected to APIs.", ar: "نعم. الفلاتر والمسارات جاهزة للربط مع API." },
        },
      ],
    },
  },

  /**
   * 03 – Admin Dashboard – React + Vite
   */
  {
    id: "admin-dashboard",
    universe: 3,
    slug: "project-3",
    focusKeyword: { en: "admin dashboard", ar: "لوحة تحكم" },
    seoTitle: { en: "Admin Dashboard: Tables & Analytics Case Study", ar: "لوحة تحكم: دراسة حالة الجداول والتحليلات" },
    seoDescription: {
      en: "Admin dashboard with analytics, tables, routing, and themes. Clean UX, protected routes, and bilingual UI.",
      ar: "لوحة تحكم بتحليلات وجداول ومسارات وسمات. تجربة نظيفة، مسارات محمية، ودعم لغتين.",
    },
    name: { en: "Admin Control Dashboard", ar: "لوحة تحكم إدارية متكاملة" },
    tagline: {
      en: "Admin dashboard with analytics, users, orders, products, settings, notifications, and themes.",
      ar: "لوحة تحكم إدارية تضم التحليلات والمستخدمين والطلبات والمنتجات والإعدادات والتنبيهات والسمات.",
    },
    description: {
      en: [
        "A production-style admin dashboard built with React, Vite, Tailwind CSS, and Zustand.",
        "It includes a simple mock login flow, protected routes, responsive sidebar and topbar, analytics with Recharts, rich tables for users, orders, and products, plus notifications, themes, dark mode, and English/Arabic support.",
      ].join(" "),
      ar: [
        "لوحة تحكم إدارية احترافية مبنية بـ React وVite وTailwind CSS وZustand.",
        "توفّر تدفّق تسجيل دخول تجريبي، ومسارات محمية، وشريطًا جانبيًا ورأسيًا متجاوبين، وصفحات تحليلات بمخططات Recharts، وجداول متقدمة للمستخدمين والطلبات والمنتجات، إلى جانب نظام تنبيهات وسمات متعددة ووضع داكن ودعم للغتين العربية والإنجليزية.",
      ].join(" "),
    },
    techStack: ["React", "Vite", "TypeScript", "Tailwind CSS", "Zustand", "React Router", "Recharts", "Framer Motion"],
    tags: ["dashboard", "admin", "ui", "frontend", "rtl"],
    repoUrl: "https://github.com/Mohamed-El-Hussainy-gitme/dashboard-admin",
    liveUrl: "https://mohamed-el-hussainy-gitme.github.io/dashboard-admin",
    screens: [
      { id: "admin-1", src: "/assets/project3/Screenshot 2025-12-02 190940.png", alt: "Admin dashboard — analytics overview" },
      { id: "admin-2", src: "/assets/project3/Screenshot 2025-12-02 191014.png", alt: "Admin dashboard — analytics sales view" },
      { id: "admin-3", src: "/assets/project3/Screenshot 2025-12-02 191048.png", alt: "Admin dashboard — users table" },
      { id: "admin-4", src: "/assets/project3/Screenshot 2025-12-02 191205.png", alt: "Admin dashboard — users sorting and filters" },
      { id: "admin-5", src: "/assets/project3/Screenshot 2025-12-02 191304.png", alt: "Admin dashboard — orders table sorting" },
      { id: "admin-6", src: "/assets/project3/Screenshot 2025-12-02 191353.png", alt: "Admin dashboard — products management table" },
      { id: "admin-7", src: "/assets/project3/Screenshot 2025-12-02 191426.png", alt: "Admin dashboard — notifications center" },
      { id: "admin-8", src: "/assets/project3/Screenshot 2025-12-02 191505.png", alt: "Admin dashboard — appearance settings" },
      { id: "admin-9", src: "/assets/project3/Screenshot 2025-12-02 191606.png", alt: "Admin dashboard — Arabic RTL settings" },
      { id: "admin-10", src: "/assets/project3/Screenshot 2025-12-02 191634.png", alt: "Admin dashboard — dark mode settings" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "Analytics, users, orders, products, settings, notifications, themes, dark mode, and a responsive dashboard layout.",
          ar: "صفحات تحليلات ولوحات بيانات، إدارة مستخدمين وطلبات ومنتجات، إعدادات وتنبيهات وسمات متعددة، ووضع داكن في تخطيط لوحة تحكم متجاوب.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "Designing a clean admin UX with protected routes, flexible layout, and clear data presentation.",
          ar: "تصميم تجربة لوحة تحكم نظيفة مع مسارات محمية وتخطيط مرن وعرض واضح ومنظّم للبيانات.",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "Front-end engineering, state management with Zustand, chart integration, and UI system.",
          ar: "تطوير الواجهة الأمامية، وإدارة الحالة باستخدام Zustand، وربط المخططات، وبناء نظام مكوّنات الواجهة.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "Dashboards fail when tables are inconsistent, filters reset, and navigation is unclear. Admin users needed predictable workflows.",
        ar: "لوحات التحكم تفشل عندما تكون الجداول غير ثابتة والفلاتر تُعاد دون سبب والتنقل غير واضح. كان المطلوب مسار إداري متوقع وسهل.",
      },
      solution: {
        en: "Built a structured admin dashboard: protected routes, consistent navigation, analytics, and rich tables with clear states (loading/empty/error).",
        ar: "تم بناء لوحة تحكم منظمة: مسارات محمية، تنقل ثابت، تحليلات، وجداول قوية مع حالات واضحة (تحميل/فارغ/خطأ).",
      },
      outcome: {
        en: "A production-style admin dashboard UI that feels stable, fast to use, and easy to scale for more modules.",
        ar: "نتيجة المشروع لوحة تحكم بطابع إنتاجي تبدو مستقرة وسريعة وسهلة التوسع لإضافة أقسام جديدة.",
      },
      role: {
        en: "Dashboard UI engineering + state design + table patterns.",
        ar: "هندسة واجهة لوحة التحكم + تصميم الحالة + أنماط الجداول.",
      },
      stack: {
        en: "React • TypeScript • Zustand • Recharts",
        ar: "React • TypeScript • Zustand • Recharts",
      },
      steps: {
        en: [
          "Design navigation and module layout",
          "Define protected routes and auth mock flow",
          "Build table components (sorting, pagination patterns)",
          "Add analytics charts and summary cards",
          "Implement themes + dark mode + RTL support",
          "Polish animations and responsiveness",
        ],
        ar: [
          "تصميم التنقل وهيكلة الأقسام",
          "تحديد المسارات المحمية وتدفق دخول تجريبي",
          "بناء مكونات الجداول (فرز/أنماط ترقيم)",
          "إضافة مخططات التحليلات وبطاقات الملخص",
          "تنفيذ السمات والوضع الداكن ودعم RTL",
          "تحسين الحركة والاستجابة للموبايل",
        ],
      },
      faqs: [
        {
          q: { en: "Does it include real authentication?", ar: "هل يوجد تسجيل دخول حقيقي؟" },
          a: { en: "It includes a mock flow and protected routes pattern. It can be connected to a real auth system.", ar: "يوجد تدفق تجريبي ونمط مسارات محمية ويمكن ربطه بمصادقة حقيقية." },
        },
        {
          q: { en: "Are tables reusable?", ar: "هل الجداول قابلة لإعادة الاستخدام؟" },
          a: { en: "Yes. The UI follows reusable table patterns and consistent states.", ar: "نعم. تم بناء أنماط جداول قابلة لإعادة الاستخدام مع حالات ثابتة." },
        },
        {
          q: { en: "Can it become a real admin for a store?", ar: "هل تصلح كلوحة لمتجر؟" },
          a: { en: "Yes. Modules like orders/products/users are already structured for a store admin.", ar: "نعم. أقسام الطلبات والمنتجات والمستخدمين منظمة لتناسب لوحة متجر." },
        },
      ],
    },
  },

  /**
   * 04 – Animation Studio
   */
  {
    id: "animation-studio",
    universe: 4,
    slug: "project-4",
    focusKeyword: { en: "web animation", ar: "تصميم حركات" },
    seoTitle: { en: "Web Animation Editor: Animation Studio Case Study", ar: "تصميم حركات: دراسة حالة Animation Studio" },
    seoDescription: {
      en: "Web animation editor with timeline and export. Generate CSS keyframes and React motion code from a visual UI.",
      ar: "محرر حركات بخط زمني وتصدير. إنشاء CSS keyframes وكود React للحركة من واجهة بصرية.",
    },
    name: { en: "Animation Studio", ar: "Animation Studio – محرر حركات للويب" },
    tagline: {
      en: "Web-based animation editor with timeline, layers, live preview, and export to CSS, HTML, JSON, and React.",
      ar: "محرر حركات على الويب بخط زمني وطبقات ومعاينة حيّة وتصدير إلى CSS وHTML وJSON وReact.",
    },
    description: {
      en: [
        "Animation Studio is a lightweight front-end animation editor that runs entirely in the browser.",
        "It gives you a mini timeline, layers panel, and live preview so you can design motion visually, then export clean CSS keyframes, HTML structure, JSON config, or a React component using Framer Motion, with undo/redo and localStorage-powered project saving.",
      ].join(" "),
      ar: [
        "Animation Studio هو محرر حركات خفيف يعمل بالكامل داخل المتصفّح.",
        "يوفّر خطًا زمنيًا مصغّرًا ولوحة طبقات ومعاينة مباشرة لتصميم الحركة بصريًا، مع تصدير كود CSS جاهز أو هيكل HTML أو إعدادات JSON أو مكوّن React يعتمد على Framer Motion، بالإضافة إلى دعم التراجع/الإعادة وحفظ المشاريع في المتصفح عبر localStorage.",
      ].join(" "),
    },
    techStack: ["HTML", "CSS", "TypeScript", "Framer Motion"],
    tags: ["animation", "motion", "frontend", "ui"],
    repoUrl: "https://github.com/Mohamed-El-Hussainy-gitme/animation-studio",
    liveUrl: "https://mohamed-el-hussainy-gitme.github.io/animation-studio/",
    screens: [
      { id: "animation-1", src: "/assets/project4/Screenshot 2025-12-01 222924.png", alt: "Web animation editor — timeline and layers panel" },
      { id: "animation-2", src: "/assets/project4/Screenshot 2025-12-01 223329.png", alt: "Web animation editor — live preview and controls" },
      { id: "animation-3", src: "/assets/project4/Screenshot 2025-12-01 223707.png", alt: "Web animation editor — export panel for CSS/HTML/JSON" },
      { id: "animation-4", src: "/assets/project4/Screenshot 2025-12-01 223957.png", alt: "Web animation editor — exported React motion code" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "Timeline, layers panel, live preview, undo/redo, device presets, and export to CSS, HTML, JSON, and React.",
          ar: "خط زمني ولوحة طبقات ومعاينة حيّة، مع تراجع وتقدّم، وخيارات أجهزة مختلفة، وتصدير إلى CSS وHTML وJSON وReact.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "Make motion design approachable for front-end developers through a browser-based editor with clean exports.",
          ar: "تبسيط تصميم الحركات لمطوّري الواجهة الأمامية عبر محرر يعمل داخل المتصفح ويصدر كودًا نظيفًا.",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "Product idea, editor UX, animation engine, and export pipeline.",
          ar: "ابتكار الفكرة، UX للمحرر، منطق الحركة، ونظام التصدير.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "Developers often waste time rewriting animation prototypes into production code. They need web animation tools that export clean code.",
        ar: "المطورون يضيعون وقتًا في تحويل نماذج الحركة إلى كود إنتاجي. كان المطلوب أداة تصميم حركات تصدر كودًا نظيفًا.",
      },
      solution: {
        en: "Created a browser-based web animation editor with timeline, layers, preview, and export to CSS keyframes and React motion components.",
        ar: "تم إنشاء محرر حركات يعمل داخل المتصفح مع خط زمني وطبقات ومعاينة وتصدير إلى CSS keyframes ومكوّنات React للحركة.",
      },
      outcome: {
        en: "A practical motion workflow: design visually, preview instantly, and export code ready to paste into real projects.",
        ar: "سير عمل عملي: تصميم بصري ثم معاينة فورية ثم تصدير كود قابل للاستخدام مباشرة داخل مشاريع حقيقية.",
      },
      role: {
        en: "Editor UX + animation logic + export formats.",
        ar: "UX للمحرر + منطق الحركة + صيغ التصدير.",
      },
      stack: {
        en: "TypeScript • Framer Motion • CSS keyframes",
        ar: "TypeScript • Framer Motion • CSS keyframes",
      },
      steps: {
        en: [
          "Define timeline model and layers structure",
          "Build preview renderer and playback controls",
          "Add undo/redo and local saving",
          "Design export pipeline (CSS/HTML/JSON/React)",
          "Polish UI states and responsive layout",
        ],
        ar: [
          "تحديد نموذج الخط الزمني وبنية الطبقات",
          "بناء المعاينة والتحكم في التشغيل",
          "إضافة التراجع/الإعادة والحفظ المحلي",
          "تصميم نظام التصدير (CSS/HTML/JSON/React)",
          "تحسين حالات الواجهة والتوافق مع الموبايل",
        ],
      },
      faqs: [
        {
          q: { en: "Does it export production-ready code?", ar: "هل التصدير مناسب للإنتاج؟" },
          a: { en: "It exports clean templates you can paste and adapt. The goal is reducing rewrite time.", ar: "يصدر قوالب نظيفة قابلة للصق والتعديل بهدف تقليل وقت إعادة الكتابة." },
        },
        {
          q: { en: "Why both CSS and React exports?", ar: "لماذا تصدير CSS وReact معًا؟" },
          a: { en: "Some projects need pure CSS; others use React motion. The tool supports both workflows.", ar: "بعض المشاريع تحتاج CSS فقط والبعض يستخدم React motion لذلك دعمنا المسارين." },
        },
        {
          q: { en: "Can designs be saved and resumed?", ar: "هل يمكن حفظ المشروع واستكماله لاحقًا؟" },
          a: { en: "Yes. Projects are saved locally and can be resumed quickly.", ar: "نعم. يتم حفظ المشاريع محليًا ويمكن استكمالها بسهولة." },
        },
      ],
    },
  },

  /**
   * 05 – HoloSpace OS
   */
  {
    id: "holospace-os",
    universe: 5,
    slug: "project-5",
    focusKeyword: { en: "3D web experience", ar: "تجربة ثلاثية الأبعاد" },
    seoTitle: { en: "3D Web Experience: HoloSpace OS Case Study", ar: "تجربة ثلاثية الأبعاد: دراسة حالة HoloSpace" },
    seoDescription: {
      en: "3D web desktop with apps, themes, and motion. WebGL-style UI with window manager and interactive modules.",
      ar: "سطح مكتب ثلاثي الأبعاد مع تطبيقات وسمات وحركة. واجهة WebGL بمدير نوافذ وتفاعل متقدم.",
    },
    name: { en: "HoloSpace OS", ar: "HoloSpace OS – نظام تشغيل ويب ثلاثي الأبعاد" },
    tagline: {
      en: "3D web operating system with desktop, windows, music player, gallery, notes, and system settings.",
      ar: "نظام تشغيل ويب ثلاثي الأبعاد مع سطح مكتب ونوافذ وتطبيقات مدمجة مثل مشغّل الموسيقى ومعرض الصور والملاحظات والإعدادات.",
    },
    description: {
      en: [
        "HoloSpace OS is a 3D spatial web operating system built with React, Vite, TypeScript, TailwindCSS, React Three Fiber, and Framer Motion.",
        "It simulates a futuristic desktop with glassmorphism UI, animated dock, launcher, command palette, notifications panel, and multiple apps such as Music, Gallery, Notes, and Settings with theme, profile, and club-mode visual/audio effects.",
      ].join(" "),
      ar: [
        "HoloSpace OS هو نظام تشغيل ويب ثلاثي الأبعاد مبني بـ React وVite وTypeScript وTailwindCSS وReact Three Fiber وFramer Motion.",
        "يقدّم سطح مكتب مستقبليًا بتصميم زجاجي، وشريط تطبيقات متحرك، وقائمة إطلاق، ولوحة أوامر، ولوحة تنبيهات، وتطبيقات مدمجة مثل مشغّل الموسيقى ومعرض الصور والملاحظات والإعدادات مع تحكم في السمات والملفات الشخصية وتأثيرات بصرية وصوتية مخصّصة لوضع Club Mode.",
      ].join(" "),
    },
    techStack: [
      "React",
      "Vite",
      "TypeScript",
      "Tailwind CSS",
      "React Three Fiber",
      "@react-three/drei",
      "Framer Motion",
      "HTML5 Audio",
    ],
    tags: ["3d", "webgl", "frontend", "ui", "motion"],
    repoUrl: "https://github.com/Mohamed-El-Hussainy-gitme/holospace-web",
    liveUrl: "https://mohamed-el-hussainy-gitme.github.io/holospace-web/",
    screens: [
      { id: "holospace-1", src: "/assets/project5/Screenshot 2025-12-06 235132.png", alt: "3D web desktop — main workspace" },
      { id: "holospace-2", src: "/assets/project5/Screenshot 2025-12-06 235225.png", alt: "3D web desktop — music player and visualizer" },
      { id: "holospace-3", src: "/assets/project5/Screenshot 2025-12-06 235303.png", alt: "3D web desktop — gallery and windows manager" },
      { id: "holospace-4", src: "/assets/project5/Screenshot 2025-12-06 235404.png", alt: "3D web desktop — themes and UI variations" },
      { id: "holospace-5", src: "/assets/project5/Screenshot 2025-12-06 235639.png", alt: "3D web desktop — notes app" },
      { id: "holospace-6", src: "/assets/project5/Screenshot 2025-12-06 235756.png", alt: "3D web desktop — settings appearance" },
      { id: "holospace-7", src: "/assets/project5/Screenshot 2025-12-06 235829.png", alt: "3D web desktop — quality settings" },
      { id: "holospace-8", src: "/assets/project5/Screenshot 2025-12-06 235902.png", alt: "3D web desktop — motion and FX settings" },
      { id: "holospace-9", src: "/assets/project5/screenshot 1.png", alt: "3D web desktop — mobile music player" },
      { id: "holospace-10", src: "/assets/project5/screenshot 2.png", alt: "3D web desktop — mobile home screen" },
      { id: "holospace-11", src: "/assets/project5/screenshot 3.png", alt: "3D web desktop — mobile theme view" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "3D desktop, glassmorphism UI, animated dock and launcher, window manager, notifications panel, and multiple built-in apps.",
          ar: "سطح مكتب ثلاثي الأبعاد، واجهة زجاجية، شريط تطبيقات وقائمة إطلاق متحركة، مدير نوافذ، لوحة تنبيهات، وتطبيقات مدمجة متعددة.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "Exploring spatial OS concepts in the browser using WebGL, motion, and system-level theming and profiles.",
          ar: "استكشاف فكرة أنظمة التشغيل المكانية داخل المتصفّح باستخدام WebGL والحركة ونظام سمات وملفات شخصية على مستوى النظام.",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "System design, 3D scene composition, UI design, and front-end implementation.",
          ar: "تصميم النظام، وبناء المشهد الثلاثي الأبعاد، وتصميم الواجهة، وتنفيذ الواجهة الأمامية.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "Building a 3D web experience often becomes a performance problem or a UI chaos. The goal was a usable 3D desktop that still feels like a real product.",
        ar: "تجارب الويب ثلاثية الأبعاد غالبًا تتحول لمشكلة أداء أو فوضى واجهة. الهدف كان بناء تجربة ثلاثية الأبعاد قابلة للاستخدام وتشبه منتجًا حقيقيًا.",
      },
      solution: {
        en: "Designed a 3D web desktop with clear UI layers: window manager, dock, launcher, and apps with theming and motion that does not overwhelm.",
        ar: "تم تصميم سطح مكتب ثلاثي الأبعاد بطبقات واجهة واضحة: مدير نوافذ وشريط تطبيقات وقائمة تشغيل وتطبيقات مع سمات وحركة محسوبة بدون إزعاج.",
      },
      outcome: {
        en: "A demo OS that proves interaction patterns (windows, apps, settings) inside a 3D web experience with responsive behavior.",
        ar: "نتيجة المشروع نظام تجريبي يثبت أنماط التفاعل (نوافذ/تطبيقات/إعدادات) داخل تجربة ثلاثية الأبعاد مع دعم الموبايل.",
      },
      role: {
        en: "3D scene + UI layering + motion + app modules.",
        ar: "المشهد ثلاثي الأبعاد + طبقات الواجهة + الحركة + بناء التطبيقات.",
      },
      stack: {
        en: "React Three Fiber • TypeScript • Framer Motion",
        ar: "React Three Fiber • TypeScript • Framer Motion",
      },
      steps: {
        en: [
          "Define desktop interaction model (windows, focus, z-index)",
          "Build 3D scene + camera behaviors",
          "Implement window manager and launcher",
          "Add apps (music, gallery, notes, settings)",
          "Create theming and profiles system",
          "Tune performance and FX settings",
        ],
        ar: [
          "تحديد نموذج التفاعل (نوافذ/تركيز/ترتيب الطبقات)",
          "بناء المشهد والكاميرا",
          "تنفيذ مدير النوافذ وقائمة التشغيل",
          "إضافة تطبيقات (موسيقى/معرض/ملاحظات/إعدادات)",
          "إنشاء نظام السمات والملفات الشخصية",
          "ضبط الأداء وإعدادات المؤثرات",
        ],
      },
      faqs: [
        {
          q: { en: "Is this built with WebGL?", ar: "هل المشروع مبني بـ WebGL؟" },
          a: { en: "Yes, through React Three Fiber with interactive UI layered on top.", ar: "نعم عبر React Three Fiber مع واجهة فوق المشهد." },
        },
        {
          q: { en: "Does it work on mobile?", ar: "هل يعمل على الموبايل؟" },
          a: { en: "Yes. Core modules have responsive views and mobile-friendly interaction.", ar: "نعم. توجد واجهات مناسبة للموبايل وتفاعل مبسط." },
        },
        {
          q: { en: "Can it be turned into a product?", ar: "هل يمكن تحويله لمنتج؟" },
          a: { en: "Yes. The architecture supports adding apps and improving performance progressively.", ar: "نعم. المعمارية تسمح بإضافة تطبيقات وتحسين الأداء تدريجيًا." },
        },
      ],
    },
  },

  /**
   * 06 – PulseReach Media (Website)
   */
  {
    id: "pulsereach-media",
    universe: 6,
    slug: "project-6",
    focusKeyword: { en: "WordPress website", ar: "موقع ووردبريس" },
    seoTitle: { en: "WordPress Website: PulseReach Media Case Study", ar: "موقع ووردبريس: دراسة حالة PulseReach" },
    seoDescription: {
      en: "WordPress website with bilingual landing pages and conversion sections. RTL-first Arabic, pricing, FAQs, and CTAs.",
      ar: "موقع ووردبريس بصفحات بيع ثنائية اللغة. RTL للعربية، باقات، FAQ، وCTA واضح للتحويل.",
    },
    name: {
      en: "PulseReach Media Website",
      ar: "PulseReach Media – موقع وكالة سوشيال ميديا (صفحات بيع باقات)",
    },
    tagline: {
      en: "Conversion-focused bilingual landing pages for social media management packages (WordPress + coded templates).",
      ar: "صفحات بيع باقات سوشيال ميديا ثنائية اللغة مع قوالب مبرمجة تركّز على التحويل داخل ووردبريس.",
    },
    description: {
      en: [
        "PulseReach Media is a bilingual (AR/EN) marketing agency website built on WordPress using Astra Child Theme and custom coded page templates.",
        "The project focuses on clean, modern UI, strong conversion sections (hero, social proof, pricing, FAQs, CTAs), RTL-first Arabic layout, and scalable template-based pages for Services, Packages, Results, and Contact with WPForms integration.",
      ].join(" "),
      ar: [
        "PulseReach Media هو موقع ثنائي اللغة (عربي/إنجليزي) لوكالة تسويق وسوشيال ميديا مبني على WordPress باستخدام Astra Child Theme وقوالب صفحات مبرمجة (Coded Templates).",
        "يركّز المشروع على واجهة حديثة وتجربة تحويل قوية عبر أقسام الهيرو، إثبات اجتماعي، الباقات والأسعار، الأسئلة الشائعة، وCTA واضح، مع دعم RTL للعربية وقابلية التوسع لصفحات الخدمات والباقات والنتائج والتواصل ودمج WPForms.",
      ].join(" "),
    },
    techStack: ["WordPress", "PHP", "Astra (Child Theme)", "HTML5", "CSS (Design System Variables)", "WPForms", "Rank Math SEO"],
    tags: ["wordpress", "landing", "seo", "technical-seo", "schema", "rtl"],
    repoUrl: "",
    liveUrl: "https://pulsereachmedia.wuaze.com/",
    screens: [
      { id: "pulsereach-1", src: "/assets/project6/1.png", alt: "WordPress website — Arabic hero and conversion layout" },
      { id: "pulsereach-2", src: "/assets/project6/2.png", alt: "WordPress website — pricing and packages section" },
      { id: "pulsereach-3", src: "/assets/project6/3.png", alt: "WordPress website — services landing section" },
      { id: "pulsereach-4", src: "/assets/project6/4.png", alt: "WordPress website — results/case studies page" },
      { id: "pulsereach-5", src: "/assets/project6/5.png", alt: "WordPress website — contact page with form CTA" },
      { id: "pulsereach-6", src: "/assets/project6/6.png", alt: "WordPress website — responsive navigation on mobile" },
      { id: "pulsereach-7", src: "/assets/project6/7.png", alt: "WordPress website — mobile layout view" },
      { id: "pulsereach-8", src: "/assets/project6/8.png", alt: "WordPress website — mobile pricing view" },
      { id: "pulsereach-9", src: "/assets/project6/9.png", alt: "WordPress website — mobile FAQ and CTA blocks" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "Bilingual AR/EN, RTL-first layout, coded templates for 8 pages, pricing and conversion sections, reusable design system, and fast iteration inside WordPress.",
          ar: "ثنائي اللغة عربي/إنجليزي، دعم RTL بشكل صحيح، قوالب مبرمجة لعدة صفحات (حتى 8 صفحات)، أقسام تحويل قوية (باقات/CTA/FAQ)، نظام تصميم CSS قابل لإعادة الاستخدام، وسهولة تطوير وتعديل داخل ووردبريس.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "High-conversion landing structure, clean responsive UI, SEO-ready pages, and scalable template-driven architecture for services and packages.",
          ar: "هيكلة Landing Pages عالية التحويل، تصميم Responsive نظيف، جاهزية SEO، وبنية Templates قابلة للتوسع لصفحات الخدمات والباقات.",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "UI structure, custom template coding (PHP), design system CSS, content architecture, and basic SEO setup.",
          ar: "بناء الهيكلة والواجهات، برمجة قوالب الصفحات (PHP)، تصميم نظام CSS، تنظيم المحتوى وأقسام التحويل، وتجهيز أساسيات SEO.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "Agency websites fail when packages are unclear and CTAs are weak. The goal was a WordPress website built for conversion in AR/EN.",
        ar: "مواقع الوكالات تفشل عندما تكون الباقات غير واضحة وCTA ضعيف. كان المطلوب موقع ووردبريس مصمم للتحويل بالعربية والإنجليزية.",
      },
      solution: {
        en: "Implemented conversion-first landing templates: hero + proof + pricing + FAQ + CTA, with RTL-first Arabic and scalable template structure.",
        ar: "تم تنفيذ قوالب صفحات بيع: هيرو + إثبات اجتماعي + باقات + FAQ + CTA، مع RTL للعربية وبنية Templates قابلة للتوسع.",
      },
      outcome: {
        en: "A clearer sales structure that guides visitors to choose a package and contact through a single primary CTA.",
        ar: "بنية بيع أوضح تقود الزائر لاختيار باقة والتواصل عبر CTA أساسي واحد بدل تشتت الأزرار.",
      },
      role: {
        en: "Template coding + UI structure + SEO basics.",
        ar: "برمجة Templates + هيكلة الواجهة + أساسيات SEO.",
      },
      stack: {
        en: "WordPress • PHP templates • RankMath SEO",
        ar: "WordPress • قوالب PHP • RankMath SEO",
      },
      steps: {
        en: [
          "Define conversion sections and package layout",
          "Implement RTL-first templates and reusable blocks",
          "Integrate forms and trackable CTAs",
          "Optimize SEO titles/descriptions and schema",
          "Test responsiveness and page speed basics",
        ],
        ar: [
          "تحديد أقسام التحويل وبنية الباقات",
          "تنفيذ Templates للعربية وBlocks قابلة لإعادة الاستخدام",
          "دمج النماذج وCTA قابلة للقياس",
          "تهيئة SEO (عناوين/وصف/سكيما)",
          "اختبار الاستجابة وأساسيات السرعة",
        ],
      },
      faqs: [
        {
          q: { en: "Why WordPress for this project?", ar: "لماذا ووردبريس؟" },
          a: { en: "It enables fast iteration for content and packages while keeping templates consistent and SEO-friendly.", ar: "يسمح بتعديل المحتوى والباقات بسرعة مع الحفاظ على قوالب ثابتة وداعمة لـ SEO." },
        },
        {
          q: { en: "Is Arabic RTL handled correctly?", ar: "هل RTL مضبوط؟" },
          a: { en: "Yes. The layout is RTL-first with appropriate spacing and alignment.", ar: "نعم. تم ضبط الاتجاه والمسافات والمحاذاة للعربية." },
        },
        {
          q: { en: "Can more landing pages be added?", ar: "هل يمكن إضافة صفحات بيع جديدة؟" },
          a: { en: "Yes. Template-driven structure makes it easy to add more pages consistently.", ar: "نعم. بنية القوالب تجعل إضافة صفحات جديدة سهلة وبنفس الجودة." },
        },
      ],
    },
  },

  /**
   * 07 – Arab Tourism Platform (Website)
   */
  {
    id: "arab-tourism-platform",
    universe: 7,
    slug: "project-7",
    focusKeyword: { en: "tourism website", ar: "موقع سياحي" },
    seoTitle: { en: "Tourism Website: Arab Tourism Platform Case Study", ar: "موقع سياحي: دراسة حالة منصة السياحة" },
    seoDescription: {
      en: "Tourism website with interactive SVG map and static export. Country pages, landmark pages, and fast browsing.",
      ar: "موقع سياحي بخريطة SVG تفاعلية وتصدير Static. صفحات دول ومعالم وتصفح سريع.",
    },
    name: {
      en: "Arab Tourism Platform",
      ar: "Arab Tourism Platform – منصة المعالم السياحية العربية",
    },
    tagline: {
      en: "Arabic-first static tourism directory with an interactive SVG map, country theming, and rich landmark pages (Next.js Export).",
      ar: "دليل سياحي عربي أولًا بصفحات دول ومعالم + خريطة SVG تفاعلية + ثيمات لكل دولة، جاهز للتصدير كـ Static (Next.js Export).",
    },
    description: {
      en: [
        "Arab Tourism Platform is a modern Arabic-first tourism directory built with Next.js (App Router), React, and Tailwind CSS.",
        "It provides a country → landmarks browsing flow, an interactive SVG map of the Arab world (d3-geo + topojson + world-atlas), and detailed landmark pages including long narrative text, sources, coordinates, and image-search suggestions.",
        "The project is fully static-export ready (outputs an /out folder) and can be deployed to shared hosting like InfinityFree with no backend—data is shipped locally as JSON/CSV and generated into static pages.",
      ].join(" "),
      ar: [
        "Arab Tourism Platform هي منصة دليل سياحي عربية أولًا مبنية باستخدام Next.js (App Router) وReact وTailwind CSS.",
        "توفر تجربة تصفح دولة → معالم، وخريطة SVG تفاعلية للوطن العربي (d3-geo + topojson-client + world-atlas)، وصفحات معالم غنية تحتوي على سرد عربي طويل، مصادر، إحداثيات، واقتراحات بحث عن الصور.",
        "المشروع مُجهّز للتصدير كـ Static بالكامل (ينتج مجلد /out) ويمكن رفعه على استضافات Shared مثل InfinityFree بدون أي Backend، حيث يتم الاعتماد على بيانات محلية JSON/CSV تُحوّل إلى صفحات ثابتة.",
      ].join(" "),
    },
    techStack: [
      "Next.js (App Router)",
      "React",
      "Tailwind CSS",
      "Static Export (output: 'export')",
      "d3-geo",
      "topojson-client",
      "world-atlas",
      "Local JSON/CSV Dataset",
    ],
    tags: ["tourism", "map", "frontend", "seo"],
    repoUrl: "",
    liveUrl: "https://arabesque.lovestoblog.com/",
    screens: [
      { id: "arab-tourism-1", src: "/assets/project7/1.png", alt: "Tourism website — home with SVG map and countries directory" },
      { id: "arab-tourism-2", src: "/assets/project7/2.png", alt: "Tourism website — SVG map interactive states" },
      { id: "arab-tourism-3", src: "/assets/project7/3.png", alt: "Tourism website — country page with themed header and cards" },
      { id: "arab-tourism-4", src: "/assets/project7/4.png", alt: "Tourism website — landmark details page with long narrative" },
      { id: "arab-tourism-5", src: "/assets/project7/5.png", alt: "Tourism website — sources, coordinates, and image search suggestions" },
      { id: "arab-tourism-6", src: "/assets/project7/6.png", alt: "Tourism website — search results for landmarks" },
      { id: "arab-tourism-7", src: "/assets/project7/7.png", alt: "Tourism website — mobile responsive map layout" },
      { id: "arab-tourism-8", src: "/assets/project7/8.png", alt: "Tourism website — country theming via CSS variables" },
      { id: "arab-tourism-9", src: "/assets/project7/Screenshot_2025-12-28-22-08-38-245_com.android.chrome.jpg", alt: "Tourism website — mobile country details view" },
      { id: "arab-tourism-10", src: "/assets/project7/Screenshot_2025-12-28-22-07-12-883_com.android.chrome[1].jpg", alt: "Tourism website — mobile landmark page view" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "Arabic-first UI, country → landmarks directory, interactive SVG map (d3-geo/topojson), per-country theming via CSS variables, and rich landmark pages (narrative + sources + coordinates). Fully static export to /out for shared hosting.",
          ar: "واجهة عربية أولًا، دليل دول → معالم، خريطة SVG تفاعلية (d3-geo/topojson)، ثيم لكل دولة عبر CSS Variables، وصفحات معالم غنية (سرد + مصادر + إحداثيات). تصدير Static كامل إلى /out لرفع المشروع على استضافات Shared.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "Performance-friendly static architecture, clean responsive UI, scalable dataset-driven pages, and map usability on mobile (hover/focus/tap).",
          ar: "بنية Static سريعة وخفيفة، واجهة Responsive نظيفة، صفحات قابلة للتوسع بالاعتماد على Dataset محلي، وتحسين تجربة الخريطة على الموبايل (tap/hover/focus).",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "UI/UX implementation, components system, static routing, SVG map integration, theming system, and data utilities for JSON/CSV.",
          ar: "تنفيذ الواجهات وتجربة المستخدم، بناء نظام مكوّنات، إعداد صفحات Static، دمج خريطة SVG، بناء نظام الثيمات، وتجهيز أدوات بيانات JSON/CSV.",
        },
      },
      {
        id: "deployment",
        label: { en: "Deployment", ar: "النشر والاستضافة" },
        body: {
          en: "Static export-ready producing /out for uploading via FTP to shared hosting.",
          ar: "جاهز للتصدير كـ Static مع مجلد /out للرفع عبر FTP على الاستضافات المشتركة.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "Tourism directories become heavy when they rely on backend queries for every page. The project needed a fast tourism website that works on shared hosting.",
        ar: "مواقع الأدلة السياحية تصبح ثقيلة عندما تعتمد على باك إند لكل صفحة. كان المطلوب موقع سياحي سريع يعمل على استضافات Shared بدون باك إند.",
      },
      solution: {
        en: "Built a static-export architecture: dataset-driven pages (countries/landmarks) + interactive SVG map + long landmark pages with sources and coordinates.",
        ar: "تم بناء بنية Static Export: صفحات تولَّد من Dataset (دول/معالم) + خريطة SVG تفاعلية + صفحات معالم غنية بسرد ومصادر وإحداثيات.",
      },
      outcome: {
        en: "Fast browsing, easy deployment on shared hosting, and scalable content structure for adding more landmarks without backend complexity.",
        ar: "تصفح سريع ونشر سهل على الاستضافات المشتركة وبنية قابلة للتوسع لإضافة معالم جديدة بدون تعقيد باك إند.",
      },
      role: {
        en: "UI/UX + static routing + map integration + dataset utilities.",
        ar: "UI/UX + مسارات Static + دمج الخريطة + أدوات البيانات.",
      },
      stack: {
        en: "Next.js export • d3-geo • topojson • Tailwind",
        ar: "Next.js export • d3-geo • topojson • Tailwind",
      },
      steps: {
        en: [
          "Design country → landmark browsing flow",
          "Build interactive SVG map and theming",
          "Create static pages from JSON/CSV dataset",
          "Write long landmark page structure (facts/sources)",
          "Prepare static export and hosting-ready output",
        ],
        ar: [
          "تصميم تدفق دولة → معالم",
          "بناء خريطة SVG تفاعلية ونظام ثيمات",
          "توليد صفحات ثابتة من JSON/CSV",
          "إنشاء بنية صفحة المعلم (حقائق/مصادر)",
          "تجهيز التصدير والنشر على الاستضافة",
        ],
      },
      faqs: [
        {
          q: { en: "Why static export?", ar: "لماذا Static Export؟" },
          a: { en: "It removes backend cost and keeps pages fast on shared hosting.", ar: "لأنه يلغي تكلفة الباك إند ويجعل الصفحات سريعة على الاستضافات المشتركة." },
        },
        {
          q: { en: "Is the map usable on mobile?", ar: "هل الخريطة مناسبة للموبايل؟" },
          a: { en: "Yes. Interaction is designed for tap and focus, not hover-only.", ar: "نعم. تم ضبط التفاعل للمس والضغط وليس hover فقط." },
        },
        {
          q: { en: "Can new landmarks be added easily?", ar: "هل إضافة معالم جديدة سهلة؟" },
          a: { en: "Yes. Add data entries and rebuild; pages are generated automatically.", ar: "نعم. بإضافة البيانات ثم إعادة البناء يتم توليد الصفحات تلقائيًا." },
        },
      ],
    },
  },

  /**
   * 08 – Rose E-commerce
   */
  {
    id: "rose-ecommerce",
    universe: 8,
    slug: "rose-ecommerce-website-development",
    focusKeyword: { en: "e-commerce website", ar: "متجر إلكتروني" },
    seoTitle: { en: "E-commerce Website: Rose Store Case Study", ar: "متجر إلكتروني: دراسة حالة مشروع Rose" },
    seoDescription: {
      en: "E-commerce website + admin dashboard + database. Clean UX, fast flows, and SEO-ready structure for real sales.",
      ar: "متجر إلكتروني + لوحة تحكم + قاعدة بيانات. تجربة شراء واضحة، إدارة أسرع، وبنية جاهزة لـ SEO لتحقيق مبيعات.",
    },
    name: { en: "Rose E-commerce Website Development", ar: "تطوير متجر Rose الإلكتروني" },
    tagline: {
      en: "Full store + admin dashboard + database for operational speed.",
      ar: "متجر كامل + لوحة تحكم + قاعدة بيانات لتسريع الإدارة والبيع.",
    },
    description: {
      en: "A full e-commerce build that includes a customer-facing storefront, an admin dashboard for products/orders, and a structured database layer. The goal was to reduce friction in the buying flow while keeping daily operations simple for the business team.",
      ar: "مشروع متجر إلكتروني متكامل يشمل واجهة العميل، لوحة تحكم لإدارة المنتجات والطلبات، وقاعدة بيانات منظمة. الهدف كان تقليل الاحتكاك في رحلة الشراء مع الحفاظ على إدارة يومية سهلة وسريعة لفريق العمل.",
    },
    liveUrl: "",
    repoUrl: "",
    techStack: ["E-commerce", "Admin Dashboard", "Database"],
    tags: ["ecommerce", "admin", "database", "seo"],
    screens: [
      { id: "rose-01", src: "/assets/rose/01.png", alt: "E-commerce website — Rose store UI 01" },
      { id: "rose-02", src: "/assets/rose/02.png", alt: "E-commerce website — Rose store UI 02" },
      { id: "rose-03", src: "/assets/rose/03.png", alt: "E-commerce website — Rose store UI 03" },
      { id: "rose-04", src: "/assets/rose/04.png", alt: "E-commerce website — Rose store UI 04" },
      { id: "rose-05", src: "/assets/rose/05.png", alt: "E-commerce website — Rose store UI 05" },
      { id: "rose-06", src: "/assets/rose/06.png", alt: "E-commerce website — Rose store UI 06" },
      { id: "rose-07", src: "/assets/rose/07.png", alt: "E-commerce website — Rose store UI 07" },
      { id: "rose-08", src: "/assets/rose/08.png", alt: "E-commerce website — Rose store UI 08" },
      { id: "rose-09", src: "/assets/rose/09.png", alt: "E-commerce website — Rose store UI 09" },
      { id: "rose-10", src: "/assets/rose/10.png", alt: "E-commerce website — Rose store UI 10" },
      { id: "rose-11", src: "/assets/rose/11.png", alt: "E-commerce website — Rose store UI 11" },
      { id: "rose-12", src: "/assets/rose/12.png", alt: "E-commerce website — Rose store UI 12" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "Storefront + admin dashboard + database. Clear navigation, fast checkout flows, and SEO-ready structure for categories and products.",
          ar: "واجهة متجر + لوحة تحكم + قاعدة بيانات. تصفح واضح، تدفق شراء سريع، وبنية جاهزة لـ SEO للمنتجات والتصنيفات.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "Conversion-first UX for buyers, and admin experience that keeps operations simple.",
          ar: "تجربة شراء تدفع للتحويل، ولوحة تحكم تجعل الإدارة اليومية أبسط.",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "Full implementation across UI, dashboard flows, and data structure, with attention to mobile usability and SEO-friendly hierarchy.",
          ar: "تنفيذ شامل للواجهة وتجربة لوحة التحكم وبنية البيانات، مع عناية بالموبايل وبنية صفحات تدعم SEO.",
        },
      },
      {
        id: "deployment",
        label: { en: "Deployment", ar: "النشر والاستضافة" },
        body: {
          en: "Prepared for production hosting with a structure that supports future SEO landing pages.",
          ar: "مجهز للنشر مع هيكل واضح للتوسع لاحقًا وإضافة صفحات SEO إضافية.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "The business needed an e-commerce website that sells smoothly and an admin dashboard that saves time daily. Operations and sales had to scale.",
        ar: "كان المطلوب متجر إلكتروني يبيع بسلاسة مع لوحة تحكم توفر وقت الإدارة اليومي. الهدف هو تشغيل أسهل ونمو في المبيعات.",
      },
      solution: {
        en: "Built a full e-commerce website: storefront + admin dashboard + database with a clear product structure and an efficient workflow for orders and inventory.",
        ar: "تم بناء متجر إلكتروني كامل: واجهة متجر + لوحة تحكم + قاعدة بيانات مع تنظيم المنتجات وسير عمل فعال لإدارة الطلبات والمخزون.",
      },
      outcome: {
        en: "A clearer buying journey, faster admin operations, and a structure that supports SEO pages (categories/products) for long-term traffic.",
        ar: "رحلة شراء أوضح، إدارة أسرع، وبنية تدعم صفحات SEO (تصنيفات/منتجات) لزيارات طويلة المدى.",
      },
      role: {
        en: "End-to-end build: UX, storefront, dashboard flow, and data structure.",
        ar: "تنفيذ كامل: UX، واجهة المتجر، تدفق لوحة التحكم، وبنية البيانات.",
      },
      stack: {
        en: "Storefront • Admin Dashboard • Database",
        ar: "واجهة متجر • لوحة تحكم • قاعدة بيانات",
      },
      steps: {
        en: [
          "Map the checkout flow and key pages",
          "Build product/category structure and UI",
          "Implement admin workflow for products and orders",
          "Organize database and data rules",
          "Optimize mobile UX and performance basics",
          "Prepare SEO-ready hierarchy and internal linking",
        ],
        ar: [
          "تحديد مسار الشراء والصفحات الأساسية",
          "تنظيم التصنيفات والمنتجات وبناء الواجهة",
          "تنفيذ لوحة التحكم لإدارة المنتجات والطلبات",
          "تنظيم قاعدة البيانات وقواعد البيانات",
          "تحسين تجربة الموبايل وأساسيات الأداء",
          "تهيئة بنية SEO وروابط داخلية قوية",
        ],
      },
      faqs: [
        {
          q: { en: "Is it a full store with admin?", ar: "هل هو متجر كامل مع لوحة تحكم؟" },
          a: { en: "Yes. Storefront, admin dashboard, and database layer are included.", ar: "نعم. يوجد واجهة متجر ولوحة تحكم وقاعدة بيانات." },
        },
        {
          q: { en: "Can it support payments and shipping?", ar: "هل يدعم الدفع والشحن؟" },
          a: { en: "Yes, depending on providers. The structure supports adding integrations.", ar: "نعم حسب مزودي الخدمة. الهيكل يدعم إضافة التكاملات." },
        },
        {
          q: { en: "Does it help SEO?", ar: "هل يدعم SEO؟" },
          a: { en: "Yes. The hierarchy supports category and product pages with internal links.", ar: "نعم. البنية تدعم صفحات التصنيفات والمنتجات مع روابط داخلية." },
        },
      ],
    },
  },

  /**
   * 09 – GrowLik (SEO Only)
   */
  {
    id: "growlik",
    universe: 9,
    slug: "growlik",
    focusKeyword: { en: "SEO optimization", ar: "تحسين SEO" },
    seoTitle: { en: "SEO Optimization: GrowLik Case Study", ar: "تحسين SEO: دراسة حالة GrowLik" },
    seoDescription: {
      en: "Technical SEO improvements: titles, descriptions, headings, schema, and internal links for clearer snippets and ranking.",
      ar: "تحسين SEO تقني: عناوين ووصف وهيدنجز وسكيما وروابط داخلية لتحسين الترتيب والمقتطفات.",
    },
    name: { en: "GrowLik SEO Optimization", ar: "تحسين SEO لموقع GrowLik" },
    tagline: {
      en: "Technical SEO improvements for higher visibility and better snippets.",
      ar: "تحسينات SEO تقنية لرفع الظهور وتحسين المقتطفات في نتائج البحث.",
    },
    description: {
      en: "A focused SEO engagement: audit + fixes for titles, descriptions, heading structure, internal linking, and schema to improve Google visibility.",
      ar: "تعاون SEO مركز: تدقيق ثم إصلاحات للعناوين والوصف وبنية الهيدنجز والروابط الداخلية والسكيما لتحسين الظهور في Google.",
    },
    liveUrl: "",
    repoUrl: "",
    techStack: ["SEO", "Technical SEO", "Schema"],
    tags: ["seo", "technical-seo", "schema"],
    screens: [
      { id: "growlik-01", src: "/assets/growlik/01.png", alt: "SEO optimization — GrowLik page structure 01" },
      { id: "growlik-02", src: "/assets/growlik/02.png", alt: "SEO optimization — GrowLik metadata and headings 02" },
      { id: "growlik-03", src: "/assets/growlik/03.png", alt: "SEO optimization — GrowLik internal linking 03" },
      { id: "growlik-04", src: "/assets/growlik/04.png", alt: "SEO optimization — GrowLik schema and snippet clarity 04" },
    ],
    highlights: [
      {
        id: "keyPoints",
        label: { en: "Key points", ar: "أبرز النقاط" },
        body: {
          en: "SEO audit + fixes: titles, meta descriptions, heading hierarchy, and structured data for clearer search snippets.",
          ar: "تدقيق SEO ثم إصلاحات: العناوين والوصف وبنية الهيدنجز وإضافة سكيما لرفع جودة المقتطفات في البحث.",
        },
      },
      {
        id: "focus",
        label: { en: "Focus", ar: "التركيز" },
        body: {
          en: "Search visibility improvements with cleaner metadata and content structure (Google + AI search).",
          ar: "تحسين الظهور في البحث عبر ميتاداتا أوضح وبنية محتوى أنظف (Google + البحث بالذكاء الاصطناعي).",
        },
      },
      {
        id: "role",
        label: { en: "My role", ar: "الدور" },
        body: {
          en: "Technical SEO implementation: metadata, headings, internal links, schema markup, and basic performance checks.",
          ar: "تنفيذ SEO تقني: ميتاداتا، هيدنجز، روابط داخلية، سكيما، ومراجعة أساسيات الأداء.",
        },
      },
    ],
    caseStudy: {
      problem: {
        en: "The site needed SEO optimization without redesign: weak titles, unclear headings, and missing schema reduced visibility and snippet quality.",
        ar: "الموقع كان يحتاج تحسين SEO بدون إعادة تصميم: عناوين ضعيفة وهيدنجز غير واضح وسكيما غير موجودة مما يضعف الظهور والمقتطفات.",
      },
      solution: {
        en: "Applied technical SEO: rewrite titles/descriptions, fix H1/H2, strengthen internal links, add schema, and improve image alt context.",
        ar: "تم تطبيق SEO تقني: إعادة كتابة title/description، ضبط H1/H2، تقوية الروابط الداخلية، إضافة سكيما، وتحسين alt للصور بسياق واضح.",
      },
      outcome: {
        en: "Cleaner indexing signals, clearer snippets, and a structure ready for scaling content with consistent metadata rules.",
        ar: "إشارات فهرسة أوضح، مقتطفات أفضل، وبنية جاهزة للتوسع في المحتوى مع قواعد ميتاداتا ثابتة.",
      },
      role: {
        en: "Audit + metadata rewrite + schema + linking plan.",
        ar: "تدقيق + إعادة كتابة الميتاداتا + سكيما + خطة روابط داخلية.",
      },
      stack: {
        en: "Metadata • Headings • Schema • Internal Links",
        ar: "ميتا • هيدنجز • سكيما • روابط داخلية",
      },
      steps: {
        en: ["Audit priority pages", "Rewrite title/description", "Fix heading hierarchy", "Add schema markup", "Improve alt text", "Strengthen internal links"],
        ar: ["مراجعة الصفحات الأهم", "إعادة كتابة العنوان والوصف", "ضبط الهيدنجز", "إضافة السكيما", "تحسين alt", "تقوية الروابط الداخلية"],
      },
      faqs: [
        {
          q: { en: "Was any UI redesigned?", ar: "هل تم تغيير التصميم؟" },
          a: { en: "No. The work focused on SEO structure, metadata, schema, and internal linking only.", ar: "لا. العمل كان على بنية SEO والميتا والسكيما والروابط الداخلية فقط." },
        },
        {
          q: { en: "Can the same SEO approach be applied to services pages?", ar: "هل يمكن تطبيق نفس الأسلوب على الخدمات؟" },
          a: { en: "Yes. Services pages benefit from focused keywords, FAQs, and schema with internal linking.", ar: "نعم. صفحات الخدمات تستفيد جدًا من كلمات مفتاحية وFAQ وسكيما وروابط داخلية." },
        },
        {
          q: { en: "Does alt text really matter?", ar: "هل alt مهم فعلًا؟" },
          a: { en: "Yes. It improves accessibility and provides image context for search engines.", ar: "نعم. يدعم الوصول ويعطي سياقًا لمحركات البحث." },
        },
      ],
    },
  },
];

export type ProjectId = (typeof projects)[number]["id"];
