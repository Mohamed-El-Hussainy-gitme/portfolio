export type LocalizedText = { en: string; ar: string };

export type BlogBlock =
  | { type: "h2"; text: LocalizedText }
  | { type: "h3"; text: LocalizedText }
  | { type: "p"; text: LocalizedText }
  | { type: "code"; lang: string; code: string };

export type BlogPost = {
  slug: string;
  dateISO: string;
  tags: string[];
  focusKeyword: LocalizedText;
  title: LocalizedText;
  description: LocalizedText;
  blocks: BlogBlock[];
};

// ---------------------------------------------------------------------------
// Long-form blog content builder (>= ~800 words per locale, no repeated "6").
// Deterministic pool selection seeded by slug.
// ---------------------------------------------------------------------------

function hashSlug(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function pickFromPool<T>(seed: number, pool: T[], count: number): T[] {
  const out: T[] = [];
  const used = new Set<number>();
  let s = seed;
  while (out.length < Math.min(count, pool.length)) {
    // xorshift32
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    const idx = Math.abs(s) % pool.length;
    if (!used.has(idx)) {
      used.add(idx);
      out.push(pool[idx]);
    }
  }
  return out;
}

type KeywordBudget = { en: number; ar: number };

function applyKeywordBudget(
  text: LocalizedText,
  kw: LocalizedText,
  budget: KeywordBudget
): LocalizedText {
  const en = text.en.replace(/\{KW\}/g, () => {
    if (budget.en > 0) {
      budget.en -= 1;
      return kw.en;
    }
    return "this topic";
  });

  const ar = text.ar.replace(/\{KW\}/g, () => {
    if (budget.ar > 0) {
      budget.ar -= 1;
      return kw.ar;
    }
    return "هذا الموضوع";
  });

  return { en, ar };
}

const DEV_POOL: LocalizedText[] = [
  {
    en: "When you optimize {KW}, start by identifying the real bottleneck: server response time, excessive client JavaScript, slow images, or layout shifts. A single Lighthouse score is not enough. Measure one page, record LCP/TTFB/CLS, change one variable, then measure again. This workflow turns {KW} from guessing into a repeatable process.",
    ar: "عند تحسين {KW} ابدأ بتحديد عنق الزجاجة الحقيقي: وقت استجابة السيرفر، أو JavaScript زائد على العميل، أو صور بطيئة، أو اهتزاز التخطيط. نتيجة Lighthouse وحدها ليست كافية. قِس صفحة واحدة وسجّل LCP وTTFB وCLS، ثم غيّر عاملًا واحدًا وأعد القياس. بهذه الطريقة تصبح {KW} عملية قابلة للتكرار وليست تخمينًا.",
  },
  {
    en: "A common mistake in {KW} is mixing concerns: data fetching, rendering, and interaction in one component. Keep pages server-first when possible, isolate interactive widgets, and avoid importing heavy libraries into client components. The simplest architecture often delivers the best {KW} because it ships less code and reduces hydration work.",
    ar: "من الأخطاء الشائعة في {KW} خلط المسؤوليات: جلب البيانات والعرض والتفاعل داخل مكوّن واحد. اجعل الصفحة تعتمد على السيرفر قدر الإمكان، واعزل المكوّنات التفاعلية، وتجنب استيراد مكتبات ثقيلة داخل مكوّنات العميل. أبسط معمارية غالبًا تعطي أفضل {KW} لأنها ترسل كودًا أقل وتقلل عبء الـhydration.",
  },
  {
    en: "If your UI is a dashboard, {KW} depends on predictable state. Tables, filters, and pagination should be driven by a single query state. Persist it to the URL so users can share a filtered view. This also improves technical SEO for public dashboards and reduces support questions because the UI behavior becomes consistent.",
    ar: "إذا كانت الواجهة Dashboard فإن {KW} تعتمد على حالة State واضحة ومتوقعة. الجداول والفلاتر والترقيم يجب أن تُدار من حالة Query واحدة. اربطها بالـURL ليتمكن المستخدم من مشاركة نفس الفلترة. هذا يدعم أيضًا SEO التقني للصفحات العامة ويقلل أسئلة الدعم لأن سلوك الواجهة يصبح ثابتًا.",
  },
  {
    en: "For forms, {KW} is strongly tied to validation UX. Validate on blur and on submit, show one actionable message per field, and keep loading states explicit. The user should always know what is happening. Clean form UX reduces drop-offs and increases conversion, which is a practical business outcome of {KW}.",
    ar: "في النماذج، {KW} مرتبطة جدًا بتجربة التحقق. تحقق عند الخروج من الحقل وعند الإرسال، واعرض رسالة واحدة واضحة لكل حقل، واجعل حالات التحميل صريحة. يجب أن يفهم المستخدم ما يحدث دائمًا. تجربة النماذج النظيفة تقلل التسرب وترفع التحويل، وهذا أثر تجاري مباشر لـ {KW}.",
  },
  {
    en: "When integrating APIs, {KW} fails if errors are silent. Centralize your fetch wrapper, standardize error parsing, and design the UI for retries and empty states. These patterns reduce production incidents. The result is a product that feels stable, and stability is a major signal users associate with high-quality {KW}.",
    ar: "عند ربط API، تفشل {KW} إذا كانت الأخطاء صامتة. وحّد دالة الطلب، وطبّع تحليل الأخطاء، وصمّم الواجهة لإعادة المحاولة وحالات الفراغ. هذه الأنماط تقلل مشاكل الإنتاج. والنتيجة منتج يبدو مستقرًا، والاستقرار علامة أساسية يشعر بها المستخدم عند جودة {KW}.",
  },
  {
    en: "In bilingual products, {KW} is not only layout direction. You must prevent language mixing, handle numbers and punctuation correctly, and mirror icons only when meaning requires it. Use logical CSS properties and test the UI on real Arabic content—not placeholder short labels. This approach protects {KW} at scale.",
    ar: "في المنتجات ثنائية اللغة، {KW} ليست مجرد اتجاه. يجب منع خلط اللغات، والتعامل الصحيح مع الأرقام وعلامات الترقيم، وعكس الأيقونات عندما يتطلب المعنى ذلك. استخدم خصائص CSS المنطقية واختبر ببيانات عربية حقيقية وليس عناوين قصيرة تجريبية. هذا يحمي {KW} مع توسع المنتج.",
  },
];

const CLIENT_POOL: LocalizedText[] = [
  {
    en: "From a client perspective, {KW} means clarity: what the service includes, what deliverables you receive, and how progress is reported. A professional website build should not be mysterious. When you can explain scope, timeline, and responsibilities in plain language, you gain trust and close deals faster. That is why content matters for {KW}.",
    ar: "من منظور العميل، {KW} تعني الوضوح: ماذا تشمل الخدمة، وما المخرجات التي سيستلمها، وكيف سيتم الإبلاغ عن التقدم. بناء موقع احترافي لا يجب أن يكون غامضًا. عندما تشرح النطاق والمدة والمسؤوليات بلغة بسيطة، تزيد الثقة وتغلق الصفقات أسرع. لذلك المحتوى جزء أساسي من {KW}.",
  },
  {
    en: "If someone searches for {KW}, they often want results: more leads, clearer branding, or better conversions. Your page should answer those goals with specific outcomes, not generic promises. Mention performance, SEO foundations, accessibility, and mobile UX because these are the reasons a website becomes profitable, not just beautiful.",
    ar: "عندما يبحث شخص عن {KW} فهو يريد نتيجة: عملاء محتملين أكثر، أو هوية أوضح، أو تحويل أعلى. يجب أن تجيب الصفحة عن هذه الأهداف بنتائج محددة لا وعود عامة. اذكر الأداء وأساسيات SEO وإتاحة الوصول وتجربة الموبايل لأن هذه عوامل تجعل الموقع مربحًا وليس مجرد شكل جميل.",
  },
  {
    en: "A strong title and description help {KW} get clicks, but the on-page structure closes the click. Use one H1, clear H2 sections, and a simple CTA. Avoid repeating the same button five times. One primary action with a clear WhatsApp message often converts better than noisy pages.",
    ar: "العنوان والوصف القويان يساعدان {KW} على الحصول على نقرات، لكن بنية الصفحة هي التي تحسم القرار. استخدم H1 واحدًا وأقسام H2 واضحة وCTA بسيط. تجنب تكرار نفس الزر خمس مرات. إجراء واحد أساسي برسالة واتساب واضحة غالبًا يحول أفضل من صفحة مزدحمة.",
  },
  {
    en: "If the project is e-commerce, {KW} should highlight checkout simplicity, speed, and trust signals: clean product pages, clear shipping policies, and a stable admin dashboard. These details are what customers feel. They also produce better reviews and repeat purchases, which is the real ROI of {KW}.",
    ar: "إذا كان المشروع متجرًا إلكترونيًا، فيجب أن تركز {KW} على بساطة الشراء والسرعة وعناصر الثقة: صفحات منتج نظيفة، وسياسات شحن واضحة، ولوحة تحكم مستقرة. هذه التفاصيل هي ما يشعر به العميل. كما تؤدي لمراجعات أفضل وشراء متكرر، وهذا العائد الحقيقي لـ {KW}.",
  },
];

const MISTAKE_POOL: LocalizedText[] = [
  {
    en: "A frequent problem is writing a title that sounds clever but does not include the focus term. If the keyword is missing, users cannot confirm relevance in one glance, and the click drops. Strong {KW} starts with a clear title, then the page proves it with headings and examples.",
    ar: "مشكلة متكررة هي كتابة عنوان يبدو ذكيًا لكنه لا يحتوي الكلمة المفتاحية. عندما تغيب الكلمة لا يستطيع المستخدم تأكيد الصلة بسرعة فتقل النقرات. {KW} القوية تبدأ بعنوان واضح ثم تثبت ذلك داخل الصفحة بعناوين وأمثلة.",
  },
  {
    en: "Another mistake is weak image context. A gallery without meaningful alt text wastes SEO potential. Describe the UI purpose: dashboard filtering, product page layout, or checkout flow. When images support the story, {KW} becomes believable and search engines understand the page better.",
    ar: "خطأ آخر هو ترك الصور بلا سياق. معرض صور بلا ALT مفيد يضيع فرصة SEO. صف الهدف: فلترة لوحة التحكم، تصميم صفحة المنتج، أو مسار الدفع. عندما تخدم الصور القصة تصبح {KW} أكثر إقناعًا وتفهم محركات البحث الصفحة بشكل أفضل.",
  },
  {
    en: "Do not publish thin pages. If the reader leaves without a concrete step, the content feels generic. Add a checklist, an example, and a simple decision rule. This is how {KW} content earns bookmarks and referrals.",
    ar: "لا تنشر صفحات ضعيفة. إذا خرج القارئ دون خطوة قابلة للتطبيق فسيبدو المحتوى عامًا. أضف قائمة تنفيذ ومثالًا وقاعدة قرار بسيطة. بهذا يصبح محتوى {KW} مفيدًا ويستحق الحفظ والمشاركة.",
  },
  {
    en: "Avoid mixing multiple offers on the same section: 'Request a quote', 'Contact', 'WhatsApp', 'Email' all at once. Pick one primary CTA, and make the message specific to {KW}. Specific messages reduce back-and-forth and increase conversion.",
    ar: "تجنب خلط عروض كثيرة في نفس القسم: طلب عرض سعر، تواصل، واتساب، إيميل في وقت واحد. اختر CTA واحدًا أساسيًا واجعل الرسالة مرتبطة بـ {KW}. الرسالة المحددة تقلل الأسئلة وتزيد التحويل.",
  },
];

const QUERY_POOL: { en: string[]; ar: string[] } = {
  en: [
    "website development",
    "web development services",
    "technical SEO",
    "Next.js performance",
    "RTL UI",
    "dashboard UI",
    "ecommerce website",
    "request a quote",
  ],
  ar: [
    "بناء ويب سايت",
    "تصميم مواقع",
    "تطوير مواقع",
    "تحسين SEO",
    "أداء Next.js",
    "واجهات RTL",
    "لوحة تحكم",
    "طلب عرض سعر",
  ],
};

const SNIPPET_POOL: { h2: LocalizedText; lang: string; code: string }[] = [
  {
    h2: { en: "Practical snippet: reduce client JS", ar: "مقطع عملي: تقليل كود العميل" },
    lang: "tsx",
    code:
      "// Keep heavy libs out of the initial bundle\n// (example pattern)\nconst Chart = dynamic(() => import('./Chart'), { ssr: false });\n\nexport function AnalyticsPanel() {\n  return (\n    <section>\n      <h2>Analytics</h2>\n      <Chart />\n    </section>\n  );\n}",
  },
  {
    h2: { en: "Practical snippet: query-driven UI state", ar: "مقطع عملي: حالة UI مبنية على Query" },
    lang: "ts",
    code:
      "type Query = { q?: string; page: number; status?: 'all'|'active'|'archived' };\n\nexport function normalizeQuery(q: Partial<Query>): Query {\n  return {\n    q: q.q?.trim() || undefined,\n    page: Math.max(1, Number(q.page || 1)),\n    status: q.status || 'all',\n  };\n}",
  },
  {
    h2: { en: "Practical snippet: FAQ schema (JSON-LD)", ar: "مقطع عملي: سكيما FAQ (JSON-LD)" },
    lang: "json",
    code:
      "{\n  \"@context\": \"https://schema.org\",\n  \"@type\": \"FAQPage\",\n  \"mainEntity\": [\n    {\n      \"@type\": \"Question\",\n      \"name\": \"How long does it take?\",\n      \"acceptedAnswer\": {\n        \"@type\": \"Answer\",\n        \"text\": \"It depends on scope, content readiness, and review cycles.\"\n      }\n    }\n  ]\n}",
  },
  {
    h2: { en: "Practical snippet: RTL-safe layout", ar: "مقطع عملي: تخطيط آمن لـ RTL" },
    lang: "css",
    code:
      ".card {\n  padding-inline: 16px;\n  margin-inline: auto;\n  text-align: start;\n}\n\n.icon {\n  /* mirror only when it changes meaning */\n  transform: none;\n}",
  },
];

function longFormBlocks(slug: string, kw: LocalizedText): BlogBlock[] {
  const seed = hashSlug(slug);

  // Keep keyword repetition clean: 4–6 total inside the long body (title/metadata already includes it).
  const budget: KeywordBudget = { en: 5, ar: 5 };

  // More depth: pick more paragraphs
  const picked = pickFromPool(seed, [...DEV_POOL, ...CLIENT_POOL, ...MISTAKE_POOL], 16).map((p) =>
    applyKeywordBudget(p, kw, budget)
  );

  const querySeed = hashSlug(slug + "-q");
  const queryEn = pickFromPool(querySeed, QUERY_POOL.en, 6);
  const queryAr = pickFromPool(querySeed, QUERY_POOL.ar, 6);

  // Vary checklist length per post (not always the same steps count)
  const checklist = {
    en: [
      `Define the intent for {KW} (one page, one goal).`,
      `Write a title that starts with {KW} and adds a clear benefit.`,
      `Write a description that sells the click (proof + action).`,
      `Use one H1, then clear H2 sections.`,
      `Add internal links connecting posts, services, and projects.`,
      `Validate speed: images, fonts, and client JavaScript.`,
      `Add schema where it fits (BlogPosting / FAQPage / Service).`,
      `Write alt text that describes the image in context.`,
      `Ship, measure, then iterate with one change at a time.`,
      `Create one supporting post and link back to the main page.`,
    ],
    ar: [
      `حدد نية البحث لـ {KW} (صفحة واحدة = هدف واحد).`,
      `اكتب عنوانًا يبدأ بـ {KW} ويضيف فائدة واضحة.`,
      `اكتب وصفًا يقنع بالنقر (إثبات + دعوة).`,
      `استخدم H1 واحدًا ثم أقسام H2 واضحة.`,
      `أنشئ روابط داخلية تربط المقالات والخدمات والمشاريع.`,
      `افحص السرعة: الصور والخطوط وJavaScript على العميل.`,
      `أضف السكيما المناسبة (BlogPosting / FAQPage / Service).`,
      `اكتب ALT للصور يصفها ضمن سياقها.`,
      `انشر، قِس، ثم حسّن بتغيير واحد في كل مرة.`,
      `اكتب مقالًا داعمًا واربطه بالصفحة الأساسية.`,
    ],
  };

  const checklistLen = 7 + (seed % 4); // 7..10
  const snippet = pickFromPool(seed ^ 0x9e3779b9, SNIPPET_POOL, 1)[0];

  const mistakesIntro = applyKeywordBudget(
    {
      en: "Most pages fail because they try to target too many intents. Keep one keyword per page, then build supporting content around it.",
      ar: "تفشل أغلب الصفحات لأنها تحاول استهداف نوايا كثيرة. ركّز كلمة واحدة لكل صفحة ثم ابنِ محتوى داعم حولها.",
    },
    kw,
    budget
  );

  const mistakeCTA = applyKeywordBudget(
    {
      en: "Avoid repeating the same CTA everywhere. One primary action with a message tailored to {KW} often converts better than noisy pages.",
      ar: "تجنب تكرار زر التواصل في كل مكان. إجراء واحد أساسي برسالة مرتبطة بـ {KW} غالبًا يحول أفضل من صفحة مزدحمة.",
    },
    kw,
    budget
  );

  const faq1 = applyKeywordBudget(
    {
      en: "Q: How long does {KW} usually take? A: It depends on scope. Focused sites ship faster, while dashboards and e-commerce need more iterations and QA.",
      ar: "س: كم يستغرق {KW} عادة؟ ج: يعتمد على النطاق. موقع مركز قد يُنفذ أسرع، بينما لوحات التحكم والمتاجر تحتاج تكرارات واختبارات أكثر.",
    },
    kw,
    budget
  );

  const faq2 = applyKeywordBudget(
    {
      en: "Q: What makes {KW} rank better? A: Clear intent, strong titles/descriptions, internal links, and fast pages with the right schema.",
      ar: "س: ما الذي يجعل {KW} يتصدر؟ ج: نية بحث واضحة، عناوين ووصف قوي، روابط داخلية، صفحات سريعة، وسكيما مناسبة.",
    },
    kw,
    budget
  );

  const faq3 = applyKeywordBudget(
    {
      en: "Q: What is the biggest mistake? A: Trying to target everything on one page. Focus one keyword per page and support it with related content.",
      ar: "س: ما أكبر خطأ؟ ج: محاولة استهداف كل شيء في صفحة واحدة. ركّز كلمة مفتاحية واحدة لكل صفحة وادعمها بمحتوى مرتبط.",
    },
    kw,
    budget
  );

  return [
    { type: "h2", text: { en: "Deep dive", ar: "شرح تفصيلي" } },
    ...picked.map((t) => ({ type: "p", text: t } as BlogBlock)),

    { type: "h2", text: { en: "Common mistakes to avoid", ar: "أخطاء شائعة تجنبها" } },
    { type: "p", text: mistakesIntro },
    { type: "p", text: mistakeCTA },

    { type: "h2", text: { en: "Search queries people actually use", ar: "صياغات بحث يستخدمها الناس فعلاً" } },
    {
      type: "p",
      text: {
        en: "If your goal is traffic and leads, map this post to real queries people type into Google and AI search tools.",
        ar: "إذا كان هدفك زيارات وعملاء، اربط المقال بصياغات بحث حقيقية يكتبها الناس في Google والبحث بالذكاء الاصطناعي.",
      },
    },
    { type: "p", text: { en: `• ${queryEn.join(" • ")}`, ar: `• ${queryAr.join(" • ")}` } },

    { type: "h2", text: snippet.h2 },
    { type: "code", lang: snippet.lang, code: snippet.code },

    { type: "h2", text: { en: "Implementation checklist", ar: "قائمة تنفيذ" } },
    ...Array.from({ length: checklistLen }).map((_, i) => {
      const item: LocalizedText = { en: `• ${checklist.en[i]}`, ar: `• ${checklist.ar[i]}` };
      return { type: "p", text: applyKeywordBudget(item, kw, budget) } as BlogBlock;
    }),

    { type: "h2", text: { en: "Quick FAQ", ar: "أسئلة سريعة" } },
    { type: "p", text: faq1 },
    { type: "p", text: faq2 },
    { type: "p", text: faq3 },
  ];
}

// ---------------------------------------------------------------------------
// Posts (short titles, avoid repeating the same number in every post)
// ---------------------------------------------------------------------------

export const blogPosts: BlogPost[] = [
  {
    slug: "nextjs-performance-patterns",
    dateISO: "2026-01-14",
    tags: ["Next.js", "Performance", "SEO"],
    focusKeyword: { en: "Next.js performance", ar: "أداء Next.js" },
    title: { en: "Next.js performance patterns that improve LCP", ar: "أداء Next.js: أنماط عملية لتحسين LCP" },
    description: {
      en: "Speed up LCP, reduce JS, and cache smartly. Improve Next.js performance with real patterns and a checklist.",
      ar: "خطوات عملية لتحسين LCP وتقليل JavaScript وكاش ذكي. حسّن أداء Next.js بأنماط واضحة وقائمة تنفيذ.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "Next.js performance is rarely one magic change. It is a series of small, repeatable decisions: what runs on the server, what runs on the client, and what must load in the first viewport.",
          ar: "أداء Next.js ليس تعديلًا سحريًا واحدًا. إنه سلسلة قرارات صغيرة قابلة للتكرار: ما الذي يعمل على السيرفر، وما الذي يعمل على العميل، وما الذي يجب تحميله في أول شاشة.",
        },
      },
      {
        type: "p",
        text: {
          en: "Before optimizing Next.js performance, measure LCP/TTFB/CLS on one page. Then apply one improvement at a time and re-measure. This keeps decisions grounded.",
          ar: "قبل تحسين أداء Next.js قِس LCP وTTFB وCLS في صفحة واحدة. ثم طبّق تحسينًا واحدًا في كل مرة وأعد القياس. هذا يجعل القرار مبنيًا على بيانات.",
        },
      },
      { type: "h2", text: { en: "Example: server-first page", ar: "مثال: صفحة تعتمد على السيرفر" } },
      {
        type: "code",
        lang: "tsx",
        code: "// app/page.tsx\nexport const revalidate = 3600;\n\nimport Widget from './Widget';\n\nexport default async function Page() {\n  const data = await fetch('https://example.com/api', { next: { revalidate } }).then(r => r.json());\n  return (\n    <main>\n      <h1>Dashboard</h1>\n      <Widget initialData={data} />\n    </main>\n  );\n}",
      },
      ...longFormBlocks("nextjs-performance-patterns", { en: "Next.js performance", ar: "أداء Next.js" }),
    ],
  },

  {
    slug: "technical-seo-foundations",
    dateISO: "2026-01-14",
    tags: ["SEO", "Schema", "Content"],
    focusKeyword: { en: "technical SEO", ar: "تحسين SEO" },
    title: { en: "Technical SEO foundations for higher ranking", ar: "تحسين محركات البحث (SEO): أساسيات لنتائج أقوى" },
    description: {
      en: "Titles, descriptions, schema, internal links, and crawl clarity. A technical SEO guide that drives qualified clicks.",
      ar: "عناوين ووصف وسكيما وروابط داخلية ووضوح الزحف. دليل عملي لتحسين SEO يجلب نقرات مؤهلة.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "Technical SEO is the structure that lets content compete. If your pages are unclear, crawlers and users will not trust them—even if the design looks premium.",
          ar: "تحسين SEO التقني هو البنية التي تجعل المحتوى قادرًا على المنافسة. إذا كانت الصفحات غير واضحة فلن تثق بها محركات البحث ولا المستخدم حتى لو كان التصميم فخمًا.",
        },
      },
      {
        type: "p",
        text: {
          en: "The goal of technical SEO is simple: one page answers one intent, and metadata makes that intent obvious. That is how you win qualified clicks.",
          ar: "هدف تحسين SEO التقني بسيط: كل صفحة تجيب عن نية واحدة، والميتا تجعل تلك النية واضحة. بهذه الطريقة تحصل على نقرات مؤهلة.",
        },
      },
      { type: "h2", text: { en: "Example: FAQ schema", ar: "مثال: سكيما الأسئلة الشائعة" } },
      {
        type: "code",
        lang: "json",
        code: "{\n  \"@context\": \"https://schema.org\",\n  \"@type\": \"FAQPage\",\n  \"mainEntity\": [\n    {\n      \"@type\": \"Question\",\n      \"name\": \"How long does a landing page take?\",\n      \"acceptedAnswer\": {\n        \"@type\": \"Answer\",\n        \"text\": \"Typically 5–10 days depending on content and reviews.\"\n      }\n    }\n  ]\n}",
      },
      ...longFormBlocks("technical-seo-foundations", { en: "technical SEO", ar: "تحسين SEO" }),
    ],
  },

  {
    slug: "rtl-ui-best-practices",
    dateISO: "2026-01-14",
    tags: ["RTL", "Arabic", "UI"],
    focusKeyword: { en: "RTL UI", ar: "واجهات RTL" },
    title: { en: "RTL UI engineering for clean Arabic products", ar: "واجهات (RTL): هندسة تجربة عربية نظيفة" },
    description: {
      en: "Spacing, icons, typography, forms, and tables. Build RTL UI without language mixing and with consistent behavior.",
      ar: "مسافات وأيقونات وخطوط ونماذج وجداول. ابنِ واجهات RTL بلا خلط لغات وبسلوك ثابت.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "RTL UI is not a flip switch. A clean Arabic product needs typography, spacing, and bidirectional safety so mixed tokens do not break reading flow.",
          ar: "واجهات RTL ليست زر عكس الاتجاه. المنتج العربي النظيف يحتاج خطوطًا ومسافات صحيحة وحماية ثنائية الاتجاه حتى لا تكسر الرموز المختلطة سلاسة القراءة.",
        },
      },
      {
        type: "p",
        text: {
          en: "If you ship bilingual pages, treat RTL UI as a feature: avoid language mixing, format numbers intentionally, and test real Arabic content, not placeholders.",
          ar: "إذا كنت تبني صفحات ثنائية اللغة فاعتبر واجهات RTL ميزة أساسية: امنع خلط اللغات، ونظّم الأرقام بوضوح، واختبر محتوى عربيًا حقيقيًا لا نصوصًا تجريبية.",
        },
      },
      { type: "h2", text: { en: "Example: logical CSS", ar: "مثال: CSS منطقي" } },
      { type: "code", lang: "css", code: ".card {\n  padding-inline: 16px;\n  margin-inline: auto;\n  text-align: start;\n}" },
      ...longFormBlocks("rtl-ui-best-practices", { en: "RTL UI", ar: "واجهات RTL" }),
    ],
  },

  {
    slug: "dashboard-ui-patterns",
    dateISO: "2026-01-14",
    tags: ["Dashboard", "Tables", "State"],
    focusKeyword: { en: "dashboard UI", ar: "لوحة تحكم" },
    title: { en: "Dashboard UI patterns for tables and filters", ar: "لوحة تحكم: أنماط للجداول والفلاتر" },
    description: {
      en: "Stable query state, pagination, empty states, and filters. Build dashboard UI that feels fast and predictable.",
      ar: "حالة Query ثابتة وترقيم وحالات فراغ وفلاتر. ابنِ لوحة تحكم سريعة وسهلة التوقع.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "Dashboard UI becomes frustrating when filters reset, pagination breaks, or state is split across components. The fix is to treat the dashboard as a query-driven surface.",
          ar: "لوحة تحكم تصبح مزعجة عندما تعيد الفلاتر ضبط نفسها أو يختل الترقيم أو تتشتت الحالة بين المكونات. الحل هو التعامل معها كسطح قائم على Query واضحة.",
        },
      },
      {
        type: "code",
        lang: "ts",
        code: "type Query = { q?: string; status?: 'all'|'active'|'archived'; page: number };\n\nfunction toSearchParams(query: Query) {\n  const p = new URLSearchParams();\n  if (query.q) p.set('q', query.q);\n  if (query.status && query.status !== 'all') p.set('status', query.status);\n  p.set('page', String(query.page));\n  return p;\n}",
      },
      ...longFormBlocks("dashboard-ui-patterns", { en: "dashboard UI", ar: "لوحة تحكم" }),
    ],
  },

  {
    slug: "react-component-architecture",
    dateISO: "2026-01-14",
    tags: ["React", "TypeScript", "Architecture"],
    focusKeyword: { en: "React architecture", ar: "معمارية React" },
    title: { en: "React architecture that scales in real apps", ar: "معمارية React: تنظيم يتوسع مع المنتج" },
    description: {
      en: "State boundaries, naming, testing, and stable exports. A practical React architecture approach for fewer bugs.",
      ar: "حدود الحالة والتسمية والاختبار والتصدير. منهج عملي لمعمارية React يقلل الأخطاء.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "React architecture is a set of defaults you apply every day: where state lives, how components are named, and how boundaries prevent coupling.",
          ar: "معمارية React هي مجموعة قواعد افتراضية تطبقها يوميًا: أين تعيش الحالة، وكيف تُسمى المكونات، وكيف تمنع الحدود الاعتمادية الزائدة.",
        },
      },
      {
        type: "code",
        lang: "tsx",
        code: "// Presentational component\nexport function ProductList({ items }: { items: { id: string; name: string }[] }) {\n  return <ul>{items.map(i => <li key={i.id}>{i.name}</li>)}</ul>;\n}",
      },
      ...longFormBlocks("react-component-architecture", { en: "React architecture", ar: "معمارية React" }),
    ],
  },

  {
    slug: "api-integration-patterns",
    dateISO: "2026-01-14",
    tags: ["API", "React", "Patterns"],
    focusKeyword: { en: "API integration", ar: "ربط API" },
    title: { en: "API integration patterns for stable apps", ar: "ربط (API): أنماط لتطبيقات مستقرة" },
    description: {
      en: "Error UX, retries, caching, and typed responses. API integration patterns that improve trust and stability.",
      ar: "أخطاء واضحة، إعادة محاولة، كاش، وأنواع. أنماط ربط API ترفع الثقة والاستقرار.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "API integration is where UX breaks. The difference between a professional dashboard and a fragile one is predictable loading, clear errors, and consistent data.",
          ar: "ربط API هو المكان الذي تنهار فيه التجربة. الفرق بين لوحة احترافية وأخرى هشة هو تحميل متوقع وأخطاء واضحة وبيانات متسقة.",
        },
      },
      {
        type: "code",
        lang: "ts",
        code: "export async function api<T>(url: string, init?: RequestInit): Promise<T> {\n  const res = await fetch(url, {\n    ...init,\n    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },\n  });\n  if (!res.ok) throw new Error(`HTTP ${res.status}`);\n  return res.json() as Promise<T>;\n}",
      },
      ...longFormBlocks("api-integration-patterns", { en: "API integration", ar: "ربط API" }),
    ],
  },

  {
    slug: "image-optimization-lcp",
    dateISO: "2026-01-14",
    tags: ["Images", "LCP", "Performance"],
    focusKeyword: { en: "image optimization", ar: "تحسين الصور" },
    title: { en: "Image optimization to improve LCP and SEO", ar: "تحسين الصور: رفع (LCP) ودعم (SEO)" },
    description: {
      en: "Sizing, formats, lazy loading, and layout stability. Image optimization that speeds up LCP and improves search.",
      ar: "أحجام وصيغ وLazy loading وثبات التخطيط. تحسين الصور يسرّع LCP ويدعم نتائج البحث.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "Image optimization is one of the fastest wins for LCP. If the hero image is heavy, your SEO and conversions suffer.",
          ar: "تحسين الصور من أسرع مكاسب LCP. إذا كانت صورة الهيرو ثقيلة يتأثر SEO والتحويل.",
        },
      },
      {
        type: "code",
        lang: "html",
        code: "<img src=\"/img/hero.webp\" width=\"1200\" height=\"750\" loading=\"eager\" alt=\"Hero\" />\n<img src=\"/img/gallery-1.webp\" loading=\"lazy\" alt=\"Gallery\" />",
      },
      ...longFormBlocks("image-optimization-lcp", { en: "image optimization", ar: "تحسين الصور" }),
    ],
  },

  {
    slug: "form-handling-validation",
    dateISO: "2026-01-14",
    tags: ["Forms", "Validation", "UX"],
    focusKeyword: { en: "form validation", ar: "التحقق من النماذج" },
    title: { en: "Form validation patterns for better UX", ar: "التحقق من النماذج: تجربة (UX) أفضل" },
    description: {
      en: "Field errors, submit states, accessibility, and async checks. Form validation patterns that reduce drop-offs.",
      ar: "أخطاء الحقول وحالات الإرسال وإتاحة الوصول والتحقق غير المتزامن. أنماط تحقق تقلل التسرب.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "Form validation is a trust moment. If errors are unclear, users abandon. If states are clean, users complete the flow.",
          ar: "التحقق من النماذج لحظة ثقة. إذا كانت الأخطاء غير واضحة يترك المستخدم. وإذا كانت الحالات نظيفة يكمل المسار.",
        },
      },
      {
        type: "code",
        lang: "ts",
        code: "type Errors = Record<string, string>;\n\nfunction validate(values: Record<string, string>): Errors {\n  const e: Errors = {};\n  if (!values.email.includes('@')) e.email = 'Invalid email';\n  if (values.password.length < 8) e.password = 'Min 8 chars';\n  return e;\n}",
      },
      ...longFormBlocks("form-handling-validation", { en: "form validation", ar: "التحقق من النماذج" }),
    ],
  },

  {
    slug: "auth-route-protection",
    dateISO: "2026-01-14",
    tags: ["Auth", "Security", "Routing"],
    focusKeyword: { en: "route protection", ar: "حماية المسارات" },
    title: { en: "Auth and route protection without fragile UX", ar: "حماية المسارات: مصادقة بدون تعقيد" },
    description: {
      en: "Guard routes, handle sessions, and design redirects correctly. Route protection patterns that keep UX predictable.",
      ar: "حراسة المسارات وإدارة الجلسات وإعادة التوجيه بشكل صحيح. أنماط لحماية المسارات بتجربة متوقعة.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "Route protection is more than hiding a link. You need clear redirect rules, session checks, and good empty states.",
          ar: "حماية المسارات ليست مجرد إخفاء رابط. تحتاج قواعد إعادة توجيه واضحة وفحص جلسة وحالات فراغ جيدة.",
        },
      },
      { type: "code", lang: "ts", code: "// Pseudo-guard\nexport function canAccess(user: { role: string } | null) {\n  if (!user) return false;\n  return user.role === 'admin';\n}" },
      ...longFormBlocks("auth-route-protection", { en: "route protection", ar: "حماية المسارات" }),
    ],
  },

  {
    slug: "deploy-ci-maintainability",
    dateISO: "2026-01-14",
    tags: ["CI", "Deployment", "Maintainability"],
    focusKeyword: { en: "CI/CD", ar: "نشر CI" },
    title: { en: "CI/CD deployment for maintainable releases", ar: "نشر (CI): إصدارات مستقرة وقابلة للصيانة" },
    description: {
      en: "Build checks, previews, secrets, and rollback. A practical CI/CD approach that prevents broken releases.",
      ar: "فحوصات بناء ومعاينات وأسرار وخطة تراجع. منهج عملي لنشر CI يمنع الإصدارات المكسورة.",
    },
    blocks: [
      {
        type: "p",
        text: {
          en: "CI/CD is not only for big teams. A small product benefits from repeatable releases, preview links, and fast rollback.",
          ar: "نشر CI ليس للفرق الكبيرة فقط. حتى المشاريع الصغيرة تستفيد من إصدارات قابلة للتكرار وروابط معاينة وتراجع سريع.",
        },
      },
      { type: "code", lang: "yml", code: "# Example checks\n# - lint\n# - typecheck\n# - build\n# - preview deployment" },
      ...longFormBlocks("deploy-ci-maintainability", { en: "CI/CD", ar: "نشر CI" }),
    ],
  },
];

export function getPostBySlug(slug: string): BlogPost | undefined {
  return blogPosts.find((p) => p.slug === slug);
}
