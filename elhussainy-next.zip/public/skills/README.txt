Place your skill logo images here.

Expected naming (png recommended):
- html.png
- css.png
- javascript.png
- typescript.png
- react.png
- nextjs.png
- tailwind.png (or tailwindcss.png)
- framer-motion.png (or framer.png)
- php.png
- mysql.png
- git.png
- vite.png

You can also use normalized names, e.g. "node-js" -> node-js.png.
