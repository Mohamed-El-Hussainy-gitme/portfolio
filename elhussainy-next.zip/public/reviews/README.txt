Put review screenshots here (cropped from the original platform UI).
Examples:
  public/reviews/r1.png
  public/reviews/r2.webp

Put reviewer avatar crops here (optional):
  public/reviews/avatars/u1.png
