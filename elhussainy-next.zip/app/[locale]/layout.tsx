export const dynamic = "force-static";

export function generateStaticParams() {
  return [{ locale: "en" }, { locale: "ar" }];
}

export default function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: "en" | "ar" };
}) {
  const isAr = params.locale === "ar";

  return (
    <div lang={isAr ? "ar" : "en"} dir={isAr ? "rtl" : "ltr"}>
      {children}
    </div>
  );
}
