import NotFoundPage from "@/views/NotFoundPage";

export default function NotFound() {
  return <NotFoundPage />;
}
