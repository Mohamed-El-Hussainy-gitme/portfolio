import React from "react";

// تم إلغاء دوائر السكروول الجانبية نهائيًا
const ScrollProgressNav: React.FC = () => null;

export default ScrollProgressNav;
